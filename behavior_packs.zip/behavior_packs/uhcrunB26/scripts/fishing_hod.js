import { world, system } from "@minecraft/server";

const PROJECTILE = {
  HOOK: "minecraft:fishing_hook",
};

const ENTITY = {
  PLAYER: "minecraft:player",
};

const COMBAT = {
  DAMAGE: 0.5,
  BASE_KNOCKBACK: 1.5,
  RANDOM_KB: 0.5,
  VERTICAL: 0.5,
};

const SOUND = {
  CAST: "minecraft:item.fishing_rod.cast",
};

const TIMING = {
  REMOVE_TICKS: 1,
};

function isPlayer(entity) {
  return entity?.typeId === ENTITY.PLAYER;
}

function isFishingHook(projectile) {
  return projectile?.typeId === PROJECTILE.HOOK;
}

function canHookHit(target, source, projectile) {
  if (!isPlayer(target)) return false;
  if (!isPlayer(source)) return false;
  if (!isFishingHook(projectile)) return false;
  if (target.id === source.id) return false;
  return true;
}

function calculateKnockback() {
  return COMBAT.BASE_KNOCKBACK + Math.random() * COMBAT.RANDOM_KB;
}

function applyHookDamage(target) {
  target.applyDamage(COMBAT.DAMAGE);
}

function applyHookKnockback(target, source) {
  const dir = source.getViewDirection();
  const force = calculateKnockback();
  target.applyKnockback(dir.x, dir.z, force, COMBAT.VERTICAL);
}

function playHookSound(player) {
  player.playSound(SOUND.CAST, { volume: 0.8, pitch: 1.0 });
}

function removeProjectileLater(projectile) {
  system.runTimeout(() => {
    if (projectile?.isValid()) {
      projectile.remove();
    }
  }, TIMING.REMOVE_TICKS);
}

function onProjectileHit(e) {
  const target = e.getEntityHit()?.entity;
  const { proj: projectile, src: source } = e;

  if (!canHookHit(target, source, projectile)) return;

  applyHookDamage(target);
  applyHookKnockback(target, source);
  playHookSound(source);
  removeProjectileLater(projectile);
}

world.afterEvents.projectileHitEntity.subscribe(onProjectileHit);
