import { world } from "@minecraft/server";

const ROLE_TAG = {
  GM: "gamemode",
  ADMIN: "Admin",
  RANK_PREFIX: "rank:",
};

const CHAT_FORMAT = " §8§l»§r§7 ";

const COMMAND_POLICY = {
  gm: new Set(["tp"]),
  admin: new Set(["admin", "kill", "list", "help", "world"]),
};

function onChat(event) {
  const { sender, message } = event;

  const profile = buildPlayerProfile(sender);
  if (isAllowedCommand(message, profile)) return;

  event.cancel = true;
  broadcastChat(sender, message, profile);
}

function buildPlayerProfile(player) {
  const tags = new Set(player.getTags());

  return {
    isGm: tags.has(ROLE_TAG.GM),
    isAdmin: tags.has(ROLE_TAG.ADMIN) || hasRankTag(tags),
    rank: getRankTag(tags),
  };
}

function isAllowedCommand(message, profile) {
  const words = tokenize(message);

  return words.some((cmd) => (profile.isGm && COMMAND_POLICY.gm.has(cmd)) || (profile.isAdmin && COMMAND_POLICY.admin.has(cmd)));
}

function broadcastChat(player, message, profile) {
  const prefix = `${profile.rank}${player.name}${CHAT_FORMAT}`;
  world.sendMessage(prefix + message);
}

function tokenize(text) {
  return text.split(/\s+/);
}

function hasRankTag(tags) {
  return [...tags].some((t) => t.startsWith(ROLE_TAG.RANK_PREFIX));
}

function getRankTag(tags) {
  const rank = [...tags].find((t) => t.startsWith(ROLE_TAG.RANK_PREFIX));
  return rank ? rank.substring(ROLE_TAG.RANK_PREFIX.length) : " ";
}

world.beforeEvents.chatSend.subscribe(onChat);
