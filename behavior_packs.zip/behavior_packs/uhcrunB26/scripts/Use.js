import { world, system } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { dynamicToast } from "./message.js";

const TEAMS = [
  { id: "team1", color: "§c", name: "Red", icon: "textures/items/dye_powder_red" },
  { id: "team2", color: "§9", name: "Blue", icon: "textures/items/dye_powder_blue_new" },
  { id: "team3", color: "§g", name: "Yellow", icon: "textures/items/dye_powder_yellow" },
  { id: "team4", color: "§a", name: "Green", icon: "textures/items/dye_powder_lime" },
  { id: "team5", color: "§5", name: "Purple", icon: "textures/items/dye_powder_purple" },
  { id: "team6", color: "§b", name: "Aqua", icon: "textures/items/dye_powder_light_blue" },
  { id: "team7", color: "§6", name: "Orange", icon: "textures/items/dye_powder_orange" },
  { id: "team8", color: "§7", name: "Gray", icon: "textures/items/dye_powder_silver" },
  { id: "team9", color: "§d", name: "Pink", icon: "textures/items/dye_powder_pink" },
];

const TEAM_MAP = new Map(TEAMS.map((t) => [t.id, t]));

async function showMenu(p, title, body, buttons) {
  const form = new ActionFormData().title(title);
  if (body) form.body(body);
  buttons.forEach((b) => form.button(b.label, b.icon));
  const res = await form.show(p);
  if (!res || res.canceled) return;
  buttons[res.selection]?.action?.(p);
}

function openMainMenu(p) {
  const buttons = [
    { label: "SPAWN", icon: "textures/items/dragons_breath", action: spawnPlayer },
    ...TEAMS.map((t) => ({
      label: `${t.color}${t.name} Team`,
      icon: t.icon,
      action: () => joinTeam(p, t),
    })),
    { label: "Emotes", icon: "textures/ui/sidebar_icons/emotes.png", action: openEmoteMenu },
  ];

  if (p.hasTag("Admin")) {
    buttons.push({
      label: "Show Menu",
      icon: "textures/ui/sidebar_icons/csb_sidebar_icon",
      action: openAdminMenu,
    });
  }

  showMenu(p, "§g§r", "§7Sleeplite UHC§6Run§726", buttons);
}

function joinTeam(p, t) {
  if (!p.hasTag(t.id)) {
    world.sendMessage(dynamicToast(`${t.color}${t.name} Team §7- ${p.name}`, t.icon));
  }
  p.runCommand(`function team/addteam_${t.id.slice(-1)}`);
}

function spawnPlayer(p) {
  p.runCommand("spreadplayers 596 622 0 1 @s");
  p.playSound("random.enderchestopen", { volume: 0.9, pitch: 0.95 });
  const { x, y, z } = p.location;
  p.dimension.spawnParticle("so:light2", { x, y: y + 5, z });
}

function openAdminMenu(p) {
  const buttons = [
    { label: "Player list", action: showTeamList },
    { label: "Kill list", action: showKillList },
    { label: "Compass", action: () => p.runCommand("function sets/compass") },
    { label: "Spawn", action: () => p.runCommand("spreadplayers 596 622 0 1 @a") },
    { label: "@a", action: () => tpAll(p) },
  ];
  showMenu(p, "Show Menu", null, buttons);
}

function tpAll(p) {
  const { location } = p;
  const rotY = p.getRotation()?.y ?? 0;
  for (const t of world.getAllPlayers()) {
    t.teleport(location, {
      rotation: { x: 0, y: rotY },
      keepVelocity: false,
    });
  }
}

function showTeamList() {
  let msg = "§8----- §gUHCRun Team §8-----§f\n";
  for (const t of TEAMS) {
    const ps = [...world.getPlayers({ tags: [t.id] })];
    if (ps.length) {
      msg += `${t.color}${t.name} ${ps.length}: ${ps.map((p) => p.name).join(", ")}\n`;
    }
  }
  world.sendMessage(msg);
}

function showKillList() {
  const sb = world.scoreboard;
  const k = sb.getObjective("kills") || sb.addObjective("kills", "Kills");
  let msg = "§8----- §gUHCRun Kills §8-----§f\n";
  for (const p of world.getPlayers()) {
    const score = k.getScore(p) ?? 0;
    msg += ` §7» §f${p.name} §c${score} kill\n`;
  }
  world.sendMessage(msg);
}

const EMOTES = [
  ["Dab", "animation.humanoid.custom.dab"],
  ["Twerking", "animation.humanoid.custom.perreo"],
  ["LMAO", "animation.humanoid.custom.risa"],
  ["Cry", "animation.humanoid.custom.llorar"],
  ["Desperate", "animation.humanoid.desesperado"],
  ["T - Pose", "animation.humanoid.t-pose"],
  ["Slap", "animation.humanoid.customm.cachetada"],
  ["Flip", "animation.humanoid.flip_atras"],
  ["Throwing Money", "animation.humanoid.melapelas"],
  ["Floss", "animation.humanoid.baile"],
  ["Champion", "animation.humanoid.customm.campeon"],
  ["You're Dead", "animation.humanoid.customm.muerto"],
  ["I'm Here", "animation.humanoid.aquiestoy"],
  ["...", "animation.humanoid.naca"],
  ["Arigato", "animation.humanoid.arigato"],
  ["Lie Down", "animation.humanoid.customm.baile_16"],
  ["Sitting", "animation.humanoid.customm.baile_17"],
  ["Take the L", "animation.humanoid.customm.baile_18"],
  ["Best Mates", "animation.humanoid.customm.baile_19"],
  ["Idle", "animation.humanoid.customm.baile_20"],
  ["Flow", "animation.humanoid.customm.baile_21"],
  ["Skibidi", "animation.humanoid.customm.baile_22"],
  ["Clubbing", "animation.humanoid.customm.baile_23"],
  ["Squat", "animation.humanoid.customm.baile_24"],
  ["Hype", "animation.humanoid.customm.baile_25"],
];

function openEmoteMenu(p) {
  const buttons = [];

  buttons.push({
    label: "Clear Emote",
    action: () => clearEmote(p),
  });

  for (const [name, anim] of EMOTES) {
    buttons.push({
      label: name,
      action: () => playEmote(p, anim),
    });
  }

  showMenu(p, "§g§rEmotes", null, buttons);
}

function clearEmote(p) {
  p.runCommand("playanimation @p animation.creaking.sway");
}

function playEmote(p, anim) {
  p.runCommand(`playanimation @p ${anim} ${anim}`);
}

const CHAT_COMMANDS = {
  admin: (p) => p.hasTag("Admin") && system.runTimeout(() => openMainMenu(p), 35),
  world: (p) => p.hasTag("Admin") && system.runTimeout(() => openAdminMenu(p), 35),
  list: () => showTeamList(),
  kill: (p) => {
    p.runCommand("playsound random.chestopen @s");
    showKillList();
  },
};

function onChat(e) {
  const p = e.sender;
  const cmd = e.message.trim().toLowerCase();
  if (CHAT_COMMANDS[cmd]) {
    e.cancel = true;
    CHAT_COMMANDS[cmd](p);
  }
}

function onUse(e) {
  const { source: p, itemStack } = e;
  if (itemStack.typeId === "minecraft:compass" && (!p.hasTag("uhc") || p.hasTag("Admin"))) {
    openMainMenu(p);
  }
}

world.afterEvents.itemUse.subscribe(onUse);
world.beforeEvents.chatSend.subscribe(onChat);
