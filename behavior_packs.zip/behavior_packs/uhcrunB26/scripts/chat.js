import { world, system, GameMode } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { Stats } from "./FromD.js";

const TEAM_DATA = new Map([
  ["team1", { name: "§cRed Team", texture: "textures/items/dye_powder_red" }],
  ["team2", { name: "§9Blue Team", texture: "textures/items/dye_powder_blue_new" }],
  ["team3", { name: "§gYellow Team", texture: "textures/items/dye_powder_yellow" }],
  ["team4", { name: "§aGreen Team", texture: "textures/items/dye_powder_lime" }],
  ["team5", { name: "§5Purple Team", texture: "textures/items/dye_powder_purple" }],
  ["team6", { name: "§bAqua Team", texture: "textures/items/dye_powder_light_blue" }],
  ["team7", { name: "§6Orange Team", texture: "textures/items/dye_powder_orange" }],
  ["team8", { name: "§7Gray Team", texture: "textures/items/dye_powder_silver" }],
  ["team9", { name: "§dPink Team", texture: "textures/items/dye_powder_pink" }],
]);

function getAvailableTeams() {
  const teams = [];
  for (const [tag] of TEAM_DATA) {
    if (world.getPlayers().some((p) => p.hasTag(tag))) {
      teams.push(tag);
    }
  }
  return teams;
}

export function openTeleportMenu(p) {
  system.runTimeout(() => {
    p.playSound("note.hat", { volume: 0.9, pitch: 0.95 });
    showMainForm(p);
  }, 35);
}

async function showMainForm(p) {
  const teams = getAvailableTeams();
  const form = new ActionFormData();

  form
    .title("Teleport to UHC Player")
    .body("§eSelect a team or player to teleport.")
    .button(`Player ${world.getPlayers().length} Online`)
    .button("UHCRun Profile");

  for (const tag of teams) {
    const team = TEAM_DATA.get(tag);
    form.button(team.name, team.texture);
  }

  const res = await form.show(p);
  if (res.canceled) return;

  if (res.selection === 0) {
    showAllPlayersForm(p);
  } else if (res.selection === 1) {
    Stats(p);
  } else {
    const teamTag = teams[res.selection - 2];
    showTeamPlayersForm(p, teamTag);
  }
}

async function showAllPlayersForm(p) {
  const players = world.getPlayers();
  const form = new ActionFormData();

  form.title(`Player ${players.length} Online`).body("§eSelect a player to teleport.");

  for (const pl of players) {
    form.button(pl.name, "textures/ui/xbox4");
  }

  form.button("§cBack");

  const res = await form.show(p);
  if (res.canceled) return;

  if (res.selection === players.length) {
    showMainForm(p);
  } else {
    teleportToPlayer(p, players[res.selection]);
  }
}

async function showTeamPlayersForm(p, teamTag) {
  const team = TEAM_DATA.get(teamTag);
  if (!team) return;

  const players = world.getPlayers().filter((pl) => pl.hasTag(teamTag));
  const form = new ActionFormData();

  form.title(team.name).body("§eSelect a player to teleport.");

  for (const pl of players) {
    form.button(pl.name, team.texture);
  }

  form.button("§cBack");

  const res = await form.show(p);
  if (res.canceled) return;

  if (res.selection === players.length) {
    showMainForm(p);
  } else {
    teleportToPlayer(p, players[res.selection]);
  }
}

async function teleportToPlayer(p, target) {
  if (!p.hasTag("gamemode")) return;

  const loc = {
    x: target.location.x + Math.random() * 2 - 1,
    y: target.location.y,
    z: target.location.z + Math.random() * 2 - 1,
  };

  await p.teleport(loc, {
    dimension: target.dimension,
    facingLocation: {
      x: target.location.x,
      y: target.location.y + 1,
      z: target.location.z,
    },
    checkForBlocks: true,
  });

  await p.setGameMode(GameMode.Spectator);
  await p.runCommand("effect @s conduit_power infinite 255 true");
}

const CHAT_ROUTER = {
  tp: (p) => p.hasTag("gamemode") && openTeleportMenu(p),
};

function onChat(e) {
  const p = e.sender;
  const cmd = e.message.trim().toLowerCase();

  if (CHAT_ROUTER[cmd]) {
    e.cancel = true;
    CHAT_ROUTER[cmd](p);
  }
}

world.beforeEvents.chatSend.subscribe(onChat);
