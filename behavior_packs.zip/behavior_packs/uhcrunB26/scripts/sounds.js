import { world, system } from "@minecraft/server";

const PROJECTILE_TYPES = new Set(["minecraft:arrow", "minecraft:thrown_trident", "minecraft:snowball"]);
const TNT_BLOCK_ID = "minecraft:tnt";
const TNT_ENTITY_ID = "minecraft:tnt";

function onProjectileHit(event) {
  handleProjectileHit(event);
}

function onPlaceBlock(event) {
  handleTntPlace(event);
}

function handleProjectileHit(event) {
  const target = event.getEntityHit()?.entity;
  const { projectile, source } = normalizeProjectileEvent(event);

  if (!isValidProjectileHit(target, projectile, source)) return;
  playHitSound(source);
}

function handleTntPlace(event) {
  const block = event.block;
  if (block.typeId !== TNT_BLOCK_ID) return;

  spawnPrimedTnt(block);
}

function isValidProjectileHit(target, projectile, source) {
  if (!target || !projectile || !source) return false;
  if (target.typeId !== "minecraft:player") return false;
  if (source.typeId !== "minecraft:player") return false;
  if (!PROJECTILE_TYPES.has(projectile.typeId)) return false;
  if (target.id === source.id) return false;
  return true;
}

function playHitSound(player) {
  player.playSound("random.orb", { volume: 0.5, pitch: 1 });
}

function spawnPrimedTnt(block) {
  const { x, y, z } = block.location;
  const dim = block.dimension;

  system.run(() => {
    block.setType("minecraft:air");
    dim.spawnEntity(TNT_ENTITY_ID, {
      x: x + 0.5,
      y: y + 0.4,
      z: z + 0.5,
    });
  });
}

function normalizeProjectileEvent(event) {
  return {
    projectile: event.projectile,
    source: event.source,
  };
}

world.afterEvents.projectileHitEntity.subscribe(onProjectileHit);
world.afterEvents.playerPlaceBlock.subscribe(onPlaceBlock);
