const BROADCAST_HANDLER = {
  message: (p, v) => p.sendMessage(v),
  title: (p, v) =>
    p.onScreenDisplay.setTitle(v.title ?? "", {
      stayDuration: 200,
      fadeInDuration: 10,
      fadeOutDuration: 20,
      subtitle: v.subtitle ?? "",
    }),
  sound: (p, v) => p.playSound(v, { volume: 0.8, pitch: 1 }),
  actionBar: (p, v) => p.onScreenDisplay.setActionBar(v),
};

export function broadcast(options) {
  const players = world.getPlayers();
  for (const player of players) {
    for (const key in options) {
      const handler = BROADCAST_HANDLER[key];
      if (handler) handler(player, options[key]);
    }
  }
}
