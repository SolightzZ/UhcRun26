import { world, Player } from "@minecraft/server";

const CONFIG = {
  MAX_CPS: 18,
  WINDOW_MS: 1000,
  KICK_REASON: "CPS over",
};

const lastHitTime = new WeakMap();
const hitCount = new WeakMap();

function isPlayer(entity) {
  return entity instanceof Player;
}

function now() {
  return Date.now();
}

function resetWindow(player, time) {
  lastHitTime.set(player, time);
  hitCount.set(player, 1);
}

function incrementHit(player) {
  hitCount.set(player, hitCount.get(player) + 1);
}

function getHits(player) {
  return hitCount.get(player) ?? 0;
}

function isNewWindow(player, time) {
  const last = lastHitTime.get(player);
  return !last || time - last >= CONFIG.WINDOW_MS;
}

async function kickPlayer(player) {
  const name = player.name;
  const hits = getHits(player);

  console.warn(`[CPS] ${name} kicked: ${hits}/${CONFIG.MAX_CPS}`);
  world.sendMessage(`§c[CPS] ${name} ${hits}/${CONFIG.MAX_CPS}`);

  try {
    await player.runCommand(`kick "${name}" §r\n§fUHC§6Run§7\n§g${name} §cout: CPS ${hits}/${CONFIG.MAX_CPS}\n(Auto-cheat)`);
  } catch {
    await player.runCommand(`kick "${name}" ${CONFIG.KICK_REASON}`);
  }
}

function checkCPS(player) {
  const time = now();

  if (isNewWindow(player, time)) {
    resetWindow(player, time);
    return;
  }

  incrementHit(player);

  if (getHits(player) > CONFIG.MAX_CPS) {
    kickPlayer(player);
  }
}

function onEntityHit(event) {
  const { damagingEntity } = event;
  if (!isPlayer(damagingEntity)) return;

  checkCPS(damagingEntity);
}

world.afterEvents.entityHitEntity.subscribe(onEntityHit, {
  maxEventsPerTick: 100,
});
