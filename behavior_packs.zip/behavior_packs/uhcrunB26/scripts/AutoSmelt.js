import { world, ItemStack } from "@minecraft/server";

const LIMIT = {
  ITEM_RADIUS: 2,
  XP_SMELT_MIN: 1,
  XP_SMELT_MAX: 4,
  XP_COAL_MIN: 1,
  XP_COAL_MAX: 10,
  XP_EMERALD_MIN: 1,
  XP_EMERALD_MAX: 15,
};

const SOUND = {
  ORB: "random.orb",
  LEVEL: "random.levelup",
};

const CHANCE = {
  BOOK: 0.2,
  ABSORPTION: 0.25,
};

const BLOCK_REGISTRY = new Map([
  ["minecraft:iron_ore", "smelt"],
  ["minecraft:deepslate_iron_ore", "smelt"],
  ["minecraft:gold_ore", "smelt"],
  ["minecraft:deepslate_gold_ore", "smelt"],
  ["minecraft:coal_ore", "smelt"],

  ["minecraft:diamond_ore", "diamond"],
  ["minecraft:deepslate_diamond_ore", "diamond"],
  ["minecraft:obsidian", "diamond"],

  ["minecraft:lapis_ore", "lapis"],
  ["minecraft:deepslate_lapis_ore", "lapis"],

  ["minecraft:gravel", "oreGravel"],
  ["minecraft:emerald_ore", "oreGravel"],
  ["minecraft:deepslate_emerald_ore", "oreGravel"],

  ["fake:redstone_ores", "redstone"],
]);

const SMELT_MAP = new Map([
  ["minecraft:raw_iron", "minecraft:iron_ingot"],
  ["minecraft:raw_gold", "minecraft:gold_ingot"],
]);

const XP_ITEMS = new Set(["minecraft:coal", "minecraft:emerald"]);

const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

const playOrb = (player, volume = 0.2) => player.playSound(SOUND.ORB, { volume, pitch: 1.5 });

const spawn = (dim, typeId, amount, loc) => dim.spawnItem(new ItemStack(typeId, amount), loc);

const getNearbyItems = (player, block) =>
  player.dimension.getEntities({
    type: "minecraft:item",
    location: block.location,
    maxDistance: LIMIT.ITEM_RADIUS,
  });

const getItem = (entity) => entity.getComponent("minecraft:item").itemStack;

function smeltAlgorithm(block, player) {
  const entities = getNearbyItems(player, block);
  if (entities.length === 0) return;

  for (const e of entities) {
    const item = getItem(e);
    const out = SMELT_MAP.get(item.typeId);
    if (!out) continue;

    spawn(player.dimension, out, item.amount, e.location);
    player.addExperience(rand(LIMIT.XP_SMELT_MIN, LIMIT.XP_SMELT_MAX));
    playOrb(player);
    e.remove();
  }
}

function oreGravelAlgorithm(block, player) {
  const entities = getNearbyItems(player, block);
  if (entities.length === 0) return;

  for (const e of entities) {
    const item = getItem(e);

    if (item.typeId === "minecraft:flint") {
      spawn(player.dimension, "minecraft:arrow", item.amount, e.location);
      playOrb(player);
      e.remove();
      continue;
    }

    if (XP_ITEMS.has(item.typeId)) {
      giveOreXp(player, item.typeId);
      playOrb(player);
      e.remove();
    }
  }
}

function giveOreXp(player, typeId) {
  if (typeId === "minecraft:coal") {
    player.addExperience(rand(LIMIT.XP_COAL_MIN, LIMIT.XP_COAL_MAX));
  }
  if (typeId === "minecraft:emerald") {
    player.addExperience(rand(LIMIT.XP_EMERALD_MIN, LIMIT.XP_EMERALD_MAX));
  }
}

function diamondEffect(player) {
  playOrb(player);
}

function lapisEffect(player) {
  if (Math.random() < CHANCE.BOOK) {
    spawn(player.dimension, "minecraft:book", 1, player.location);
    player.playSound(SOUND.LEVEL, { volume: 0.2, pitch: 1.5 });
    player.onScreenDisplay.setActionBar("");
  }
}

function redstoneEffect(player) {
  player.addExperience(rand(1, 4));
  playOrb(player, 0.4);

  if (Math.random() < CHANCE.ABSORPTION) {
    player.addEffect("absorption", 600, {
      showParticles: false,
      amplifier: 0,
    });
    player.playSound(SOUND.LEVEL, { volume: 0.8, pitch: 1.5 });
    player.onScreenDisplay.setActionBar("");
  }
}

const MECHANIC = {
  smelt: smeltAlgorithm,
  oreGravel: oreGravelAlgorithm,
  diamond: (_, p) => diamondEffect(p),
  lapis: (_, p) => lapisEffect(p),
  redstone: (_, p) => redstoneEffect(p),
};

function dispatch(blockId, block, player) {
  const type = BLOCK_REGISTRY.get(blockId);
  if (!type) return;

  const handler = MECHANIC[type];
  if (handler) handler(block, player);
}

function onBreakBlock(e) {
  const { player, block, brokenBlockPermutation } = e;
  dispatch(brokenBlockPermutation.type.id, block, player);
}

world.afterEvents.playerBreakBlock.subscribe(onBreakBlock);
