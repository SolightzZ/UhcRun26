// ========================================
// UHC Manager - Start System (Refactored)
// ========================================
// ระบบจัดการการเริ่มเกม UHC
// Refactored ด้วย Clean Code principles:
// - แยก Business Logic ออกเป็น Functions
// - ใช้ Map สำหรับ O(1) event lookup
// - เพิ่ม Error Handling และ Validation
// - ง่ายต่อการขยายและทดสอบ

import { world, system, GameMode } from "@minecraft/server";

// Import Constants
import { START_CONFIG, START_EFFECTS, UHC_EVENTS } from "./constants.js";

// Import Systems
import { broadcastToPlayers, applyCameraFade, setMovementEnabled, playMultipleSounds, broadcastActionBar } from "./broadcastSystem.js";

import { spreadAllTeams, setGameModeForPlayers, removeEffectFromPlayers, spawnTeamParticles } from "./teamSystem.js";

import { filterValidPlayers, createProgressBar, safeExecute } from "./utils.js";

// ========================================
// UHC Manager Class - Refactored
// ========================================

class UHCManager {
  // === State Management ===
  static startState = {
    uhcTick: 0,
    progressBarValue: START_CONFIG.PROGRESS_TOTAL_BARS,
  };

  // ========================================
  // State Control
  // ========================================

  /**
   * รีเซ็ตสถานะระบบ
   */
  static reset() {
    this.startState.uhcTick = 0;
    this.startState.progressBarValue = START_CONFIG.PROGRESS_TOTAL_BARS;
  }

  // ========================================
  // Main Start Sequence
  // ========================================

  /**
   * Timestart - ฟังก์ชันหลักที่ถูกเรียกทุก tick
   * @param {Player[]} uhcPlayers - ผู้เล่น UHC
   */
  static Timestart(uhcPlayers) {
    // เพิ่ม tick
    this.startState.uhcTick++;

    // กรองผู้เล่น valid
    const validUHCPlayers = filterValidPlayers(uhcPlayers);
    const allPlayers = world.getPlayers();
    const validAllPlayers = filterValidPlayers(allPlayers);

    // ประมวลผล effects สำหรับผู้เล่นทั้งหมด
    this.processAllPlayerEffects(validAllPlayers);

    // ประมวลผล events สำหรับผู้เล่น UHC
    this.processUHCPlayerEvents(validUHCPlayers);

    // แสดง progress bar (หลัง tick 12)
    this.updateProgressBar(validAllPlayers);

    // รีเซ็ตเมื่อจบ countdown
    if (this.startState.uhcTick >= START_CONFIG.COUNTDOWN_END_TICK) {
      this.reset();
    }
  }

  // ========================================
  // Progress Bar System
  // ========================================

  /**
   * อัพเดต progress bar สำหรับผู้เล่นทั้งหมด
   * @param {Player[]} players - ผู้เล่นทั้งหมด
   */
  static updateProgressBar(players) {
    const { uhcTick, progressBarValue } = this.startState;

    // เริ่มแสดงหลัง PROGRESS_BAR_START tick
    if (uhcTick <= START_CONFIG.PROGRESS_BAR_START) return;

    // ลด progress bar value
    if (progressBarValue >= 0) {
      this.startState.progressBarValue--;
    }

    // แสดง progress bar ให้ทุกคน
    for (const player of players) {
      this.displayProgressBar(player);
    }
  }

  /**
   * แสดง progress bar บน action bar
   * @param {Player} player - ผู้เล่น
   */
  static displayProgressBar(player) {
    const { progressBarValue } = this.startState;

    // ถ้าหมดแล้ว ล้าง action bar
    if (progressBarValue < 0) {
      broadcastActionBar([player], "");
      return;
    }

    // สร้าง progress bar
    const totalBars = START_CONFIG.PROGRESS_TOTAL_BARS;
    const filledBars = totalBars - progressBarValue;

    const bar = createProgressBar(filledBars, totalBars, "▌", "▌", "§a", "§f");

    // สร้างข้อความเต็ม
    const message = `§fGame Start §l\u00BB ${bar} §r${progressBarValue}`;

    // แสดงบน action bar
    broadcastActionBar([player], message);

    // เล่นเสียงถ้าใกล้เริ่ม
    if (filledBars > START_CONFIG.SOUND_THRESHOLD) {
      safeExecute(() => {
        player.playSound("note.pling", { volume: 0.8, pitch: 0.75 });
      }, "Progress Bar Sound");
    }
  }

  // ========================================
  // All Player Effects Processing
  // ========================================

  /**
   * ประมวลผล effects สำหรับผู้เล่นทั้งหมด
   * @param {Player[]} players - ผู้เล่นทั้งหมด
   */
  static async processAllPlayerEffects(players) {
    const { uhcTick } = this.startState;

    // ดึง effect event จาก Map (O(1) lookup)
    const effectEvent = START_EFFECTS.get(uhcTick);
    if (!effectEvent) return;

    // ประมวลผลตาม type
    await this.handleEffectEvent(effectEvent, players);
  }

  /**
   * จัดการ effect event แต่ละ type
   * @param {Object} event - effect event
   * @param {Player[]} players - ผู้เล่น
   */
  static async handleEffectEvent(event, players) {
    switch (event.type) {
      case "TITLE_FADE":
        await this.applyTitleFadeEffect(players, event);
        break;

      case "SOUND":
        await this.applySoundEffect(players, event);
        break;

      case "GAME_START":
        await this.applyGameStartEffect(players, event);
        break;
    }
  }

  /**
   * ทำ title + fade effect
   * @param {Player[]} players - ผู้เล่น
   * @param {Object} event - event config
   */
  static async applyTitleFadeEffect(players, event) {
    // แสดง title
    await broadcastToPlayers(players, {
      title: "",
      titleOptions: event.title,
    });

    // ทำ camera fade
    await applyCameraFade(players, {
      fadeTime: event.fade.fadeTime,
      fadeColor: event.fade.fadeColor,
    });
  }

  /**
   * เล่นเสียง
   * @param {Player[]} players - ผู้เล่น
   * @param {Object} event - event config
   */
  static async applySoundEffect(players, event) {
    await broadcastToPlayers(players, {
      sound: event.sound,
      soundOptions: {
        volume: event.volume,
        pitch: event.pitch,
      },
    });
  }

  /**
   * ทำ game start effect
   * @param {Player[]} players - ผู้เล่น
   * @param {Object} event - event config
   */
  static async applyGameStartEffect(players, event) {
    // เปิดแสดงพิกัด
    world.gameRules.showCoordinates = true;

    // ปลดล็อกการเคลื่อนไหว
    setMovementEnabled(players, true);

    // แสดง title
    await broadcastToPlayers(players, {
      title: event.title,
    });

    // เล่นหลายเสียง
    for (const player of players) {
      playMultipleSounds(player, event.sounds);
    }
  }

  // ========================================
  // UHC Player Events Processing
  // ========================================

  /**
   * ประมวลผล events สำหรับผู้เล่น UHC
   * @param {Player[]} uhcPlayers - ผู้เล่น UHC
   */
  static async processUHCPlayerEvents(uhcPlayers) {
    const { uhcTick } = this.startState;

    // ดึง event จาก Map (O(1) lookup)
    const uhcEvent = UHC_EVENTS.get(uhcTick);
    if (!uhcEvent) return;

    // ประมวลผลตาม type
    await this.handleUHCEvent(uhcEvent, uhcPlayers);
  }

  /**
   * จัดการ UHC event แต่ละ type
   * @param {Object} event - UHC event
   * @param {Player[]} uhcPlayers - ผู้เล่น UHC
   */
  static async handleUHCEvent(event, uhcPlayers) {
    switch (event.type) {
      case "LOCK_MOVEMENT":
        await this.lockPlayerMovement(uhcPlayers);
        break;

      case "SPREAD_TEAMS":
        await this.spreadTeams();
        break;

      case "GIVE_ITEMS":
        await this.giveStartingItems(uhcPlayers);
        break;

      case "START_GAME":
        await this.startGame(uhcPlayers);
        break;
    }
  }

  /**
   * ล็อกการเคลื่อนไหวและเปลี่ยนเป็น Adventure mode
   * @param {Player[]} uhcPlayers - ผู้เล่น UHC
   */
  static async lockPlayerMovement(uhcPlayers) {
    // เปลี่ยนเป็น Adventure mode
    setGameModeForPlayers(uhcPlayers, GameMode.Adventure);

    // ล็อกการเคลื่อนไหว
    setMovementEnabled(uhcPlayers, false);
  }

  /**
   * กระจายทีม
   */
  static async spreadTeams() {
    await spreadAllTeams();
  }

  /**
   * ให้ไอเทมเริ่มต้น
   * @param {Player[]} uhcPlayers - ผู้เล่น UHC
   */
  static async giveStartingItems(uhcPlayers) {
    // ให้ไอเทมตาม config
    for (const item of START_CONFIG.ITEMS) {
      await this.giveItem(uhcPlayers, item);
    }
  }

  /**
   * ให้ไอเทมหนึ่งชิ้นแก่ผู้เล่น
   * @param {Player[]} players - ผู้เล่น
   * @param {Object} item - config ไอเทม
   */
  static async giveItem(players, item) {
    for (const player of players) {
      await safeExecute(async () => {
        if (item.type === "loot") {
          // ใช้ loot table
          await player.runCommand(`loot replace entity @a[tag=uhc] slot.hotbar ${item.slot} loot "${item.table}"`);
        } else if (item.type === "item") {
          // ใช้ replaceitem
          await player.runCommand(`replaceitem entity @a[tag=uhc] slot.hotbar ${item.slot} ${item.id} ${item.count || 1}`);
        }
      }, `Give Item Slot ${item.slot}`);
    }
  }

  /**
   * เริ่มเกมจริง
   * @param {Player[]} uhcPlayers - ผู้เล่น UHC
   */
  static async startGame(uhcPlayers) {
    // แสดง particle effects
    spawnTeamParticles();

    // ลบ invisibility effect
    removeEffectFromPlayers(uhcPlayers, "invisibility");

    // เปลี่ยนเป็น Survival mode
    setGameModeForPlayers(uhcPlayers, GameMode.Survival);
  }
}

// ========================================
// Script Event Handler
// ========================================

system.afterEvents.scriptEventReceive.subscribe((event) => {
  if (!event.sourceEntity) return;

  switch (event.id) {
    case "start:clear":
    case "s:c":
      UHCManager.reset();
      break;
  }
});

// ========================================
// Export
// ========================================

export { UHCManager };
