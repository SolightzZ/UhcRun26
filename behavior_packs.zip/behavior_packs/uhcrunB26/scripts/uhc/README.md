# UHC Game System - Clean Code Refactored

## 📋 สารบัญ

- [ภาพรวม](#ภาพรวม)
- [โครงสร้างไฟล์](#โครงสร้างไฟล์)
- [การปรับปรุง Clean Code](#การปรับปรุง-clean-code)
- [Big O Optimization](#big-o-optimization)
- [การใช้งาน](#การใช้งาน)
- [ตัวอย่างการขยาย](#ตัวอย่างการขยาย)

---

## 🎯 ภาพรวม

โปรเจกต์นี้เป็นการ **Refactor** โค้ด Minecraft Bedrock Script API (UHC Game) ตามหลักการ **Clean Code**:

### ✨ จุดเด่นหลัก

- **แยก Constants และ Configuration** - ปรับค่าได้ง่าย ไม่ต้องแก้โค้ด
- **แยก Business Logic** - แต่ละ module ทำหน้าที่ชัดเจน
- **Functional Programming** - ใช้ pure functions, immutable data
- **Big O Optimization** - ใช้ Map/Set สำหรับ O(1) lookup
- **Type Safety** - JSDoc comments สำหรับ auto-completion
- **Error Handling** - Safe execute functions ป้องกัน crash
- **ง่ายต่อการขยาย** - เพิ่ม feature ใหม่โดยไม่กระทบโค้ดเดิม

---

## 📁 โครงสร้างไฟล์

```
uhc-game/
├── constants.js              # ค่าคงที่และ Configuration ทั้งหมด
├── utils.js                  # Utility functions ใช้ร่วมกัน
├── borderSystem.js           # ระบบจัดการ Border และ Particles
├── broadcastSystem.js        # ระบบส่งข้อความและ Effects
├── scoreboardSystem.js       # ระบบจัดการ Scoreboard
├── teamSystem.js             # ระบบจัดการทีม
├── main-refactored.js        # Game Controller หลัก
└── start-refactored.js       # Start Sequence Manager
```

### 🗂️ รายละเอียดแต่ละไฟล์

#### **constants.js**

เก็บค่าคงที่ทั้งหมดที่ใช้ในเกม:

- `BORDER_CONFIG` - การตั้งค่า border
- `PARTICLE_CONFIG` - การตั้งค่า particle effects
- `TEAM_CONFIG` - ข้อมูลทีม
- `GAME_EVENTS` - Events ตาม timeline (Map)
- `START_CONFIG` - การตั้งค่าการเริ่มเกม
- และอื่นๆ

#### **utils.js**

Utility functions ที่ใช้ร่วมกัน:

- Player validation functions
- Mathematical calculations
- Array utilities
- String utilities (progress bar)
- Promise utilities (parallel execution)

#### **borderSystem.js**

จัดการทุกอย่างเกี่ยวกับ border:

- คำนวณการหด border
- แสดง particle effects
- เตือนผู้เล่นนอก border
- ทำความเสียหายผู้เล่นนอก border

#### **broadcastSystem.js**

จัดการการส่งข้อความและ effects:

- Broadcast messages, titles, sounds
- Camera effects (fade)
- Input control (lock/unlock movement)
- Parallel execution สำหรับประสิทธิภาพ

#### **scoreboardSystem.js**

จัดการ scoreboard:

- สร้าง/หา objectives
- ตั้งค่า scores
- อัพเดต scoreboard แบบ batch

#### **teamSystem.js**

จัดการทีม:

- กระจายทีมไปตำแหน่งสุ่ม
- นับจำนวนทีมที่เหลือ
- ตรวจสอบเงื่อนไขชัยชนะ
- จัดการ game modes

#### **main-refactored.js**

Game Controller หลัก:

- Game loop management
- Event processing (ใช้ Map สำหรับ O(1))
- Border updates
- Victory system

#### **start-refactored.js**

Start Sequence Manager:

- Countdown system
- Progress bar display
- Team spreading
- Item distribution

---

## 🧹 การปรับปรุง Clean Code

### 1. **Separation of Concerns**

แยกโค้ดออกเป็น modules ตามหน้าที่:

```javascript
// ❌ Before: ทุกอย่างอยู่ใน 1 คลาส
class UHCGame {
  static borderRadius = 500;
  static countdownTimes = new Set([90, 15, 5]);
  // ... functions ...
}

// ✅ After: แยกตามหน้าที่
import { BORDER_CONFIG } from "./constants.js";
import { calculateNewBorderRadius } from "./borderSystem.js";
```

### 2. **Extract Functions**

แยก logic ออกเป็น functions เล็กๆ ที่ทำหน้าที่เดียว:

```javascript
// ❌ Before: function ใหญ่ทำหลายอย่าง
static Warning(player) {
  const { x, z, y } = player.location;
  if (Math.abs(x) > this.borderRadius || Math.abs(z) > this.borderRadius) {
    player.dimension.spawnParticle("arrow", {...});
    if (Math.random() < 0.65) {
      player.applyDamage(3, {...});
      player.camera.fade({...});
    }
  }
}

// ✅ After: แยกเป็น functions เล็ก
export function isOutsideBorder(location, radius) {
  return Math.abs(location.x) > radius || Math.abs(location.z) > radius;
}

export function warnPlayerOutsideBorder(player, borderRadius) {
  if (!isOutsideBorder(player.location, borderRadius)) return;

  spawnWarningArrow(player);
  applyWarningEffects(player);
}
```

### 3. **Named Constants**

ใช้ชื่อที่มีความหมายแทนตัวเลข magic numbers:

```javascript
// ❌ Before
if (Math.random() < 0.65) {
  player.applyDamage(3, { cause: "void" });
}

// ✅ After
if (shouldDealDamage(WARNING_CONFIG.DAMAGE_CHANCE)) {
  player.applyDamage(WARNING_CONFIG.DAMAGE_AMOUNT, {
    cause: WARNING_CONFIG.DAMAGE_CAUSE,
  });
}
```

### 4. **Declarative over Imperative**

เขียนโค้ดแบบ declarative ที่บอกว่า "ต้องการอะไร" แทน "ทำยังไง":

```javascript
// ❌ Before: Imperative
let bar = "";
for (let i = 0; i < totalBars; i++) {
  bar += i < greenBars ? "§a▌" : "§f▌";
}

// ✅ After: Declarative
const bar = createProgressBar(greenBars, totalBars, "▌", "▌", "§a", "§f");
```

### 5. **Single Responsibility**

แต่ละ function ทำหน้าที่เดียว:

```javascript
// ❌ Before: function ทำหลายอย่าง
static Effects(players) {
  let all = 0;
  for (const player of players) {
    switch (this.uhcTick) {
      case 1:
        player.onScreenDisplay.setTitle(...);
        player.camera.fade(...);
        all++;
        break;
      case 2:
        player.playSound(...);
        all++;
        break;
    }
  }
  return all > 0;
}

// ✅ After: แยก function ย่อย
static async processAllPlayerEffects(players) {
  const effectEvent = START_EFFECTS.get(this.startState.uhcTick);
  if (!effectEvent) return;

  await this.handleEffectEvent(effectEvent, players);
}

static async applyTitleFadeEffect(players, event) {
  await broadcastToPlayers(players, { title: "", titleOptions: event.title });
  await applyCameraFade(players, event.fade);
}
```

---

## ⚡ Big O Optimization

### 1. **Map สำหรับ Event Lookup (O(1))**

```javascript
// ❌ Before: Switch-case O(n) ในกรณีแย่สุด
switch (this.tickCount) {
  case 60: /* ... */ break;
  case 120: /* ... */ break;
  case 200: /* ... */ break;
  // ... 10+ cases
}

// ✅ After: Map lookup O(1)
export const GAME_EVENTS = new Map([
  [60, { type: "PVP_DISABLE", broadcast: {...} }],
  [120, { type: "BORDER_WARNING", broadcast: {...} }],
  [200, { type: "CREDIT", toast: {...} }],
]);

const event = GAME_EVENTS.get(tickCount);
if (event) await handleTimedEvent(event, players);
```

### 2. **Set สำหรับ Membership Check (O(1))**

```javascript
// ❌ Before: Array.includes() O(n)
const countdownTimes = [90, 15, 5, 4, 3, 2, 1];
if (countdownTimes.includes(time)) {
  /* ... */
}

// ✅ After: Set.has() O(1)
const countdownTimes = new Set([90, 15, 5, 4, 3, 2, 1]);
if (countdownTimes.has(time)) {
  /* ... */
}
```

### 3. **Parallel Execution**

```javascript
// ❌ Before: Sequential execution
for (const player of players) {
  await player.sendMessage(...);
}

// ✅ After: Parallel execution
await Promise.all(players.map(p => p.sendMessage(...)));

// หรือใช้ helper function
await parallelMap(players, async (player) => {
  await player.sendMessage(...);
});
```

### 4. **Early Return**

```javascript
// ❌ Before: Nested conditions
static Particles(player) {
  const distance = this.getDistance(player.location);
  if (distance <= 32) {
    // ... 50 lines of code
  }
}

// ✅ After: Early return
static spawnBorderParticles(player, borderRadius) {
  const distance = getMinDistanceToBorder(location, center, radius);

  if (distance > PARTICLE_CONFIG.PROXIMITY_THRESHOLD) return; // Early exit

  // ... particle code
}
```

---

## 🚀 การใช้งาน

### ติดตั้ง

```javascript
// ใน main behavior pack
import { UHCGame } from "./scripts/uhc-game/main-refactored.js";
import { UHCManager } from "./scripts/uhc-game/start-refactored.js";
```

### เริ่มเกม

```javascript
// ใช้ Script Event
/scriptevent main:start

// หรือใน code
UHCGame.startGame();
```

### หยุดเกม

```javascript
/scriptevent main:stop

// หรือใน code
UHCGame.stopGame();
```

### ปรับค่า Configuration

```javascript
// แก้ไขใน constants.js
export const BORDER_CONFIG = {
  INITIAL_RADIUS: 1000, // เปลี่ยนจาก 500 เป็น 1000
  FINAL_RADIUS: 10, // เปลี่ยนจาก 5 เป็น 10
  // ...
};
```

---

## 🔧 ตัวอย่างการขยาย

### เพิ่ม Event ใหม่

```javascript
// 1. เพิ่มใน constants.js
export const GAME_EVENTS = new Map([
  // ... events เดิม
  [2000, {
    type: "NIGHT_VISION",
    broadcast: {
      message: "§6Night Vision Enabled!",
      sound: "random.levelup",
    },
  }],
]);

// 2. เพิ่ม handler ใน main-refactored.js
static async handleTimedEvent(event, players) {
  switch (event.type) {
    // ... cases เดิม

    case "NIGHT_VISION":
      await broadcastToPlayers(players, event.broadcast);
      // ให้ night vision effect
      for (const player of players) {
        player.runCommand("effect @s night_vision 999999 0 true");
      }
      break;
  }
}
```

### เพิ่ม Team ใหม่

```javascript
// แก้ใน constants.js
export const TEAM_CONFIG = {
  TAGS: [..., "team10"], // เพิ่ม team10

  TEAMS: [
    // ... teams เดิม
    { tag: "team10", color: "§e", name: " Gold" },
  ],
};
```

### ปรับ Border Shrink Logic

```javascript
// แก้ใน constants.js
export const BORDER_ADJUSTMENTS = [
  { tickRange: [900, 1200], adjustment: 0.5 }, // หดช้ากว่าเดิม
  { tickRange: [1201, 1800], adjustment: 0.2 },
  { tickRange: [1801, 3000], adjustment: 0 }, // หดปกติ
];
```

### เพิ่ม Utility Function ใหม่

```javascript
// เพิ่มใน utils.js
/**
 * หาผู้เล่นที่ใกล้ที่สุด
 * @param {Player} player - ผู้เล่นตัวเอง
 * @param {Player[]} otherPlayers - ผู้เล่นอื่น
 * @returns {Player|null} - ผู้เล่นที่ใกล้ที่สุด
 */
export function findNearestPlayer(player, otherPlayers) {
  let nearest = null;
  let minDistance = Infinity;

  for (const other of otherPlayers) {
    if (other === player) continue;

    const dist = calculateDistance(player.location, other.location);
    if (dist < minDistance) {
      minDistance = dist;
      nearest = other;
    }
  }

  return nearest;
}
```

---

## 📝 หมายเหตุ

### ข้อดีของการ Refactor

✅ **อ่านง่าย** - โค้ดแต่ละส่วนทำหน้าที่ชัดเจน  
✅ **บำรุงรักษาง่าย** - แก้ไขส่วนใดส่วนหนึ่งโดยไม่กระทบส่วนอื่น  
✅ **ทดสอบง่าย** - แต่ละ function เป็น pure function  
✅ **ขยายง่าย** - เพิ่ม feature ใหม่ได้โดยไม่ต้องแก้โค้ดเดิม  
✅ **Performance ดี** - ใช้ Map/Set สำหรับ O(1) lookup  
✅ **Error Handling** - มี safe execute functions ป้องกัน crash

### Best Practices ที่ใช้

- **DRY** (Don't Repeat Yourself) - ไม่ซ้ำโค้ด
- **KISS** (Keep It Simple, Stupid) - เขียนให้เรียบง่าย
- **YAGNI** (You Aren't Gonna Need It) - ไม่เขียนโค้ดส่วนเกิน
- **Composition over Inheritance** - ใช้ composition
- **Functional Programming** - ใช้ pure functions

---

## 🎓 สรุป

การ Refactor นี้เปลี่ยนโค้ดจาก **Monolithic Class** เป็น **Modular System** ที่:

- แยก concerns ชัดเจน
- ใช้ Big O optimization
- ง่ายต่อการขยายและบำรุงรักษา
- มี error handling ที่ดี
- เป็นมิตรกับผู้พัฒนา (Developer-friendly)

**สามารถนำไปใช้ได้ทันที โดยไม่กระทบ functionality เดิม!** 🚀
