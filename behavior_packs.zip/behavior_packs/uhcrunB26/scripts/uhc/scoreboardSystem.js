// ========================================
// Scoreboard Management System
// ========================================
// ระบบจัดการ scoreboard สำหรับแสดงข้อมูลเกม

import { world } from "@minecraft/server";
import { SCOREBOARD_CONFIG } from "./constants.js";
import { safeExecute, isPlayerValid } from "./utils.js";

// ========================================
// Scoreboard Core Functions
// ========================================

/**
 * หาหรือสร้าง objective
 * @param {string} objectiveName - ชื่อ objective
 * @param {string} [displayName] - ชื่อแสดง
 * @returns {ScoreboardObjective|null} - objective หรือ null ถ้าเกิดข้อผิดพลาด
 */
export function getOrCreateObjective(objectiveName, displayName = "") {
  return safeExecute(() => {
    const scoreboard = world.scoreboard;
    return scoreboard.getObjective(objectiveName) || scoreboard.addObjective(objectiveName, displayName);
  }, "Get/Create Objective");
}

/**
 * ตั้งค่า score สำหรับ participant
 * @param {string} objectiveName - ชื่อ objective
 * @param {string} participantName - ชื่อ participant
 * @param {number} score - คะแนน
 * @returns {boolean} - true ถ้าสำเร็จ
 */
export function setScore(objectiveName, participantName, score) {
  return safeExecute(() => {
    const objective = getOrCreateObjective(objectiveName);
    if (!objective) return false;

    objective.setScore(participantName, score);
    return true;
  }, "Set Score");
}

/**
 * รับค่า score
 * @param {string} objectiveName - ชื่อ objective
 * @param {string} participantName - ชื่อ participant
 * @returns {number|null} - คะแนนหรือ null
 */
export function getScore(objectiveName, participantName) {
  return safeExecute(() => {
    const objective = getOrCreateObjective(objectiveName);
    if (!objective) return null;

    return objective.getScore(participantName);
  }, "Get Score");
}

/**
 * ลบ participant จาก objective
 * @param {string} objectiveName - ชื่อ objective
 * @param {string} participantName - ชื่อ participant
 * @returns {boolean} - true ถ้าสำเร็จ
 */
export function removeScore(objectiveName, participantName) {
  return safeExecute(() => {
    const objective = getOrCreateObjective(objectiveName);
    if (!objective) return false;

    objective.removeParticipant(participantName);
    return true;
  }, "Remove Score");
}

// ========================================
// UHC Specific Scoreboard
// ========================================

/**
 * อัพเดต UHC scoreboard สำหรับผู้เล่น
 * @param {Player} player - ผู้เล่น
 * @param {number} borderRadius - รัศมี border ปัจจุบัน
 * @param {number} tickCount - tick ปัจจุบัน
 * @returns {boolean} - true ถ้าสำเร็จ
 */
export function updateUHCScoreboard(player, borderRadius, tickCount) {
  // ตรวจสอบว่าผู้เล่นยัง valid
  if (!isPlayerValid(player)) return false;

  // อัพเดต border score (ใช้ floor เพื่อแสดงเป็นจำนวนเต็ม)
  setScore(SCOREBOARD_CONFIG.OBJECTIVE_NAME, SCOREBOARD_CONFIG.BORDER_DISPLAY, Math.floor(borderRadius));

  // อัพเดต tick score
  setScore(SCOREBOARD_CONFIG.OBJECTIVE_NAME, SCOREBOARD_CONFIG.TICK_DISPLAY, tickCount);

  return true;
}

/**
 * อัพเดต scoreboard สำหรับผู้เล่นหลายคน
 * @param {Player[]} players - รายการผู้เล่น
 * @param {number} borderRadius - รัศมี border
 * @param {number} tickCount - tick
 * @returns {number} - จำนวนผู้เล่นที่อัพเดตสำเร็จ
 */
export function updateScoreboardForPlayers(players, borderRadius, tickCount) {
  let successCount = 0;

  for (const player of players) {
    if (updateUHCScoreboard(player, borderRadius, tickCount)) {
      successCount++;
    }
  }

  return successCount;
}

/**
 * ล้าง UHC scoreboard
 * @returns {boolean} - true ถ้าสำเร็จ
 */
export function clearUHCScoreboard() {
  return safeExecute(() => {
    const scoreboard = world.scoreboard;
    const objective = scoreboard.getObjective(SCOREBOARD_CONFIG.OBJECTIVE_NAME);

    if (objective) {
      scoreboard.removeObjective(objective);
    }

    return true;
  }, "Clear UHC Scoreboard");
}

/**
 * รีเซ็ต UHC scoreboard (ลบแล้วสร้างใหม่)
 * @returns {boolean} - true ถ้าสำเร็จ
 */
export function resetUHCScoreboard() {
  clearUHCScoreboard();
  return !!getOrCreateObjective(SCOREBOARD_CONFIG.OBJECTIVE_NAME, "");
}
