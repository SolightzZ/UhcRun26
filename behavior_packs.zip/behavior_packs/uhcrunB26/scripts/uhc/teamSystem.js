// ========================================
// Team Management System
// ========================================
// ระบบจัดการทีม: กระจายทีม, นับทีม, ตรวจสอบชัยชนะ

import { world, GameMode } from "@minecraft/server";
import { TEAM_CONFIG, START_CONFIG, VICTORY_CONFIG } from "./constants.js";
import { getPlayerTeam, getTeamInfo, getActiveTeams, filterValidPlayers, randomElement, safeExecute, logError } from "./utils.js";

// ========================================
// Team Spreading Functions
// ========================================

/**
 * กระจายทีมหนึ่งไปยังตำแหน่งสุ่ม
 * @param {string} teamTag - tag ทีม
 * @returns {Promise<boolean>} - true ถ้าสำเร็จ
 */
async function spreadSingleTeam(teamTag) {
  try {
    // หาสมาชิกทีม
    const teamMembers = world.getPlayers({ tags: [teamTag, "uhc"] });

    // ถ้าไม่มีสมาชิก ข้าม
    if (teamMembers.length === 0) return false;

    // เลือก leader (คนแรก)
    const leader = teamMembers[0];

    // กระจาย leader
    const { x, z } = START_CONFIG.SPREAD_CENTER;
    const minDist = START_CONFIG.SPREAD_MIN_DISTANCE;
    const maxRange = START_CONFIG.SPREAD_MAX_RANGE;

    await leader.runCommand(`/spreadplayers ${x} ${z} ${minDist} ${maxRange} @s`);

    // บันทึกตำแหน่ง leader
    const leaderPos = leader.location;

    // เทเลพอร์ต leader กลับไปยืนยันตำแหน่ง
    leader.teleport(leaderPos);

    // เทเลพอร์ตสมาชิกคนอื่นมาที่ leader
    for (const member of teamMembers) {
      if (member !== leader) {
        member.teleport(leaderPos);
      }
    }

    return true;
  } catch (error) {
    logError(`Spread Team: ${teamTag}`, error);
    return false;
  }
}

/**
 * กระจายทุกทีม
 * @returns {Promise<number>} - จำนวนทีมที่กระจายสำเร็จ
 */
export async function spreadAllTeams() {
  let successCount = 0;

  // วนกระจายแต่ละทีม (sequential เพื่อป้องกัน race condition)
  for (const teamTag of TEAM_CONFIG.TAGS) {
    const success = await spreadSingleTeam(teamTag);
    if (success) successCount++;
  }

  return successCount;
}

// ========================================
// Team Info Functions
// ========================================

/**
 * หาข้อมูลทีมของผู้เล่น
 * @param {Player} player - ผู้เล่น
 * @returns {Object|null} - ข้อมูลทีม {tag, color, name} หรือ null
 */
export function getPlayerTeamInfo(player) {
  const teamTag = getPlayerTeam(player, TEAM_CONFIG.TAGS);
  if (!teamTag) return null;

  return getTeamInfo(teamTag, TEAM_CONFIG.TEAMS);
}

/**
 * นับจำนวนทีมที่ยังมีสมาชิก
 * @param {Player[]} players - รายการผู้เล่น
 * @returns {Object} - {activeTeams: Set, count: number}
 */
export function countActiveTeams(players) {
  const activeTeams = getActiveTeams(players, TEAM_CONFIG.TAGS);

  return {
    activeTeams,
    count: activeTeams.size,
  };
}

/**
 * หาทีมที่ชนะ (เหลือทีมเดียว)
 * @param {Player[]} players - รายการผู้เล่น
 * @returns {Object|null} - ข้อมูลทีมที่ชนะหรือ null
 */
export function getWinningTeam(players) {
  const { activeTeams, count } = countActiveTeams(players);

  // ต้องเหลือทีมเดียว
  if (count !== 1) return null;

  // หา tag ทีมที่ชนะ
  const winningTag = Array.from(activeTeams)[0];

  // หาข้อมูลทีม
  return getTeamInfo(winningTag, TEAM_CONFIG.TEAMS);
}

// ========================================
// Team Particle Effect
// ========================================

/**
 * สร้าง particle effect สำหรับทีมสุ่ม (ทีมละ 1 คน)
 * @returns {number} - จำนวนทีมที่สร้าง particle สำเร็จ
 */
export function spawnTeamParticles() {
  const overworld = world.getDimension("overworld");
  const processedTeams = new Set();
  let successCount = 0;

  for (const teamTag of TEAM_CONFIG.TAGS) {
    // ข้ามถ้าประมวลผลแล้ว
    if (processedTeams.has(teamTag)) continue;

    // หาผู้เล่นในทีม
    const teamPlayers = world.getPlayers({ tags: [teamTag, "uhc"] });
    if (teamPlayers.length === 0) continue;

    // กรองผู้เล่น valid
    const validPlayers = filterValidPlayers(teamPlayers);
    if (validPlayers.length === 0) continue;

    // สุ่มเลือกผู้เล่น 1 คน
    const randomPlayer = randomElement(validPlayers);
    const { x, y, z } = randomPlayer.location;

    // Spawn particle
    const success = safeExecute(() => {
      overworld.spawnParticle("minecraft:huge_explosion_emitter", {
        x,
        y: y + 2.5,
        z,
      });
      return true;
    }, `Spawn Particle for ${teamTag}`);

    if (success) {
      processedTeams.add(teamTag);
      successCount++;
    }
  }

  return successCount;
}

// ========================================
// Game Mode Management
// ========================================

/**
 * เปลี่ยน game mode ให้ผู้เล่นหลายคน
 * @param {Player[]} players - รายการผู้เล่น
 * @param {GameMode} gameMode - game mode
 * @returns {number} - จำนวนที่เปลี่ยนสำเร็จ
 */
export function setGameModeForPlayers(players, gameMode) {
  let successCount = 0;

  for (const player of players) {
    const success = safeExecute(() => {
      player.setGameMode(gameMode);
      return true;
    }, `Set GameMode: ${gameMode}`);

    if (success) successCount++;
  }

  return successCount;
}

/**
 * ลบ effect จากผู้เล่นหลายคน
 * @param {Player[]} players - รายการผู้เล่น
 * @param {string} effectType - ชนิด effect
 * @returns {number} - จำนวนที่ลบสำเร็จ
 */
export function removeEffectFromPlayers(players, effectType) {
  let successCount = 0;

  for (const player of players) {
    const success = safeExecute(() => {
      player.removeEffect(effectType);
      return true;
    }, `Remove Effect: ${effectType}`);

    if (success) successCount++;
  }

  return successCount;
}

// ========================================
// Victory Check
// ========================================

/**
 * ตรวจสอบเงื่อนไขชัยชนะ
 * @param {Player[]} uhcPlayers - ผู้เล่น UHC
 * @param {number} currentTick - tick ปัจจุบัน
 * @returns {Object|null} - {shouldEnd: true, winningTeam: {...}} หรือ null
 */
export function checkVictoryCondition(uhcPlayers, currentTick) {
  // ต้องผ่าน MIN_ALIVE_CHECK_TICK
  if (currentTick <= VICTORY_CONFIG.MIN_ALIVE_CHECK_TICK) {
    return null;
  }

  // นับทีมที่เหลือ
  const { count } = countActiveTeams(uhcPlayers);

  // ต้องเหลือทีมเดียว
  if (count !== 1) return null;

  // หาทีมที่ชนะ
  const winningTeam = getWinningTeam(uhcPlayers);

  return {
    shouldEnd: true,
    winningTeam,
  };
}
