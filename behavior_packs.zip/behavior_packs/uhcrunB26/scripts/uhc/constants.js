// ========================================
// UHC Game Constants & Configuration
// ========================================
// ไฟล์นี้เก็บค่าคงที่ทั้งหมดแยกจาก business logic
// ทำให้ปรับแต่งค่าได้ง่ายโดยไม่ต้องแก้โค้ดหลัก

// === Border Configuration ===
export const BORDER_CONFIG = {
  INITIAL_RADIUS: 500, // รัศมี border เริ่มต้น (บล็อก)
  FINAL_RADIUS: 5, // รัศมี border สุดท้าย (บล็อก)
  SHRINK_DURATION: 370, // ระยะเวลาหด border (ticks)
  CENTER_POINT: { x: 0, z: 0 }, // จุดศูนย์กลาง border

  // Timing Configuration
  ACTIVATION_TICK: 900, // tick ที่ border เริ่มทำงาน
  SHRINK_START_TICK: 900, // tick เริ่มหด
  SHRINK_END_TICK: 3000, // tick สิ้นสุดการหด

  // Warning Configuration
  WARNING_RADII: [450, 400, 350, 300, 250, 200, 150, 100, 50], // รัศมีที่แจ้งเตือน
  COUNTDOWN_TIMES: [90, 15, 5, 4, 3, 2, 1], // เวลา countdown ก่อน active
};

// === Particle Configuration ===
export const PARTICLE_CONFIG = {
  MAX_PARTICLES: 50, // จำนวน particle สูงสุด
  PROXIMITY_THRESHOLD: 32, // ระยะใกล้ border ที่แสดง particle (บล็อก)
  SPACING: 1.6, // ระยะห่าง particle (บล็อก)
  RENDER_DISTANCE: 128, // ระยะ render particle สูงสุด (บล็อก)
  Y_OFFSET: 2, // ความสูงเพิ่มจากพื้น
  Y_MIN: -64, // ความสูงต่ำสุด
  Y_MAX: 320, // ความสูงสูงสุด
};

// === Warning System Configuration ===
export const WARNING_CONFIG = {
  DAMAGE_AMOUNT: 3, // ความเสียหายเมื่ออยู่นอก border
  DAMAGE_CHANCE: 0.65, // โอกาส (65%) ได้รับความเสียหาย
  DAMAGE_CAUSE: "void", // สาเหตุความเสียหาย

  // Fade Effect
  FADE_COLOR: {
    red: 0.5,
    green: 0.1,
    blue: 0.1,
  },
  FADE_TIMING: {
    fadeInTime: 0,
    holdTime: 0,
    fadeOutTime: 0.5,
  },
};

// === Team Configuration ===
export const TEAM_CONFIG = {
  TAGS: ["team1", "team2", "team3", "team4", "team5", "team6", "team7", "team8", "team9"],

  TEAMS: [
    { tag: "team1", color: "§c", name: " Red" },
    { tag: "team2", color: "§9", name: " Blue" },
    { tag: "team3", color: "§g", name: " Yellow" },
    { tag: "team4", color: "§a", name: " Green" },
    { tag: "team5", color: "§5", name: " Purple" },
    { tag: "team6", color: "§b", name: " Aqua" },
    { tag: "team7", color: "§6", name: " Orange" },
    { tag: "team8", color: "§7", name: " Gray" },
    { tag: "team9", color: "§d", name: " Pink" },
  ],
};

// === Game Events Timeline ===
// ใช้ Map เพื่อ O(1) lookup แทน switch-case
export const GAME_EVENTS = new Map([
  [
    60,
    {
      type: "PVP_DISABLE",
      broadcast: {
        message: "  : §cPVP Disabled",
        title: "§cDisabled!",
        subtitle: "การต่อสู้ถูก§cปิด§fแล้ว!",
        sound: "noti",
      },
    },
  ],
  [
    120,
    {
      type: "BORDER_WARNING",
      broadcast: {
        message: "  : World Border Active in §c900§f tick",
        title: "§l§c!",
        subtitle: "เขตแดนเจะเริ่มทำงานในอีก 720 วินาที",
        sound: "noti",
      },
    },
  ],
  [
    200,
    {
      type: "CREDIT",
      toast: {
        message: "§fUHC§6Run §7Made by SolightzZ",
        icon: "textures/uhc/solightzz",
        frame: "textures/ui/purpleBorder",
      },
      sound: "note.pling",
    },
  ],
  [
    680,
    {
      type: "PVP_ENABLE_WARNING",
      broadcast: {
        message: " §6 : PVP Enabled in 20 tick!",
        title: "§6Enabled in",
        subtitle: "จะเปิดการต่อสู้ในอีก 20 วินาที !",
        sound: "noti",
      },
    },
  ],
  [
    694,
    {
      type: "PVP_COUNTDOWN",
      broadcast: {
        message: "PVP in §c§l3 tick",
        sound: "note.pling",
      },
    },
  ],
  [
    696,
    {
      type: "PVP_COUNTDOWN",
      broadcast: {
        message: "PVP in §6§l2 tick",
        sound: "note.pling",
      },
    },
  ],
  [
    698,
    {
      type: "PVP_COUNTDOWN",
      broadcast: {
        message: "PVP in §g§l1 tick",
        sound: "world_noti",
      },
    },
  ],
  [
    700,
    {
      type: "PVP_ENABLE",
      broadcast: {
        message: "  : §aPVP Enabled",
        title: "§a- Enabled -",
        subtitle: "§fเปิดการต่อสู้แล้ว!",
        sound: "note.pling",
      },
    },
  ],
  [
    900,
    {
      type: "BORDER_ACTIVE",
      broadcast: {
        message: "§fWorld Border §aActive!",
        subtitle: "เขตแดนเริ่มทำงานแล้ว!",
        sound: "world_noti",
      },
    },
  ],
  [
    1700,
    {
      type: "MOB_DISABLE",
      broadcast: {
        message: "§cMob Spawn Disabled",
        subtitle: "§fปิดการเกิดม็อบแล้ว!",
        sound: "world_noti",
      },
    },
  ],
]);

// === Start Game Configuration ===
export const START_CONFIG = {
  // Timeline
  TEAM_SPREAD_TICK: 7, // tick ที่กระจายทีม
  ITEM_GIVE_TICK: 24, // tick ที่ให้ไอเทม
  GAME_START_TICK: 39, // tick ที่เริ่มเกมจริง
  COUNTDOWN_END_TICK: 44, // tick สิ้นสุด countdown
  PROGRESS_BAR_START: 12, // tick เริ่มแสดง progress bar

  // Spread Configuration
  SPREAD_CENTER: { x: 0, z: 0 }, // จุดกลางการกระจาย
  SPREAD_MIN_DISTANCE: 50, // ระยะห่างขั้นต่ำระหว่างทีม
  SPREAD_MAX_RANGE: 486, // ระยะสูงสุดจากจุดกลาง

  // Progress Bar
  PROGRESS_TOTAL_BARS: 25, // จำนวนแถบทั้งหมด
  SOUND_THRESHOLD: 20, // จำนวนแถบที่เริ่มเล่นเสียง

  // Starting Items (Loot Tables)
  ITEMS: [
    { slot: 0, type: "loot", table: "solight/stone_axe" },
    { slot: 1, type: "loot", table: "solight/stone_pickaxe" },
    { slot: 2, type: "item", id: "minecraft:cooked_beef", count: 3 },
    { slot: 3, type: "item", id: "minecraft:boat", count: 1 },
  ],
};

// === Start Effects Timeline ===
// ใช้ Map เพื่อ O(1) lookup
export const START_EFFECTS = new Map([
  [
    1,
    {
      type: "TITLE_FADE",
      title: {
        stayDuration: 200,
        fadeInDuration: 5,
        fadeOutDuration: 40,
      },
      fade: {
        fadeTime: { fadeInTime: 0, holdTime: 10, fadeOutTime: 10 },
        fadeColor: { red: 0.1, green: 0.1, blue: 0.1 },
      },
    },
  ],
  [
    2,
    {
      type: "SOUND",
      sound: "start",
      volume: 0.5,
      pitch: 1,
    },
  ],
  [
    39,
    {
      type: "GAME_START",
      title: "§fGood§aluck!",
      sounds: [
        { name: "startPlayer", volume: 1.5, pitch: 0.9 },
        { name: "random.explode", volume: 0.7, pitch: 0.9 },
      ],
    },
  ],
]);

// === UHC Player Events Timeline ===
export const UHC_EVENTS = new Map([
  [1, { type: "LOCK_MOVEMENT" }],
  [7, { type: "SPREAD_TEAMS" }],
  [24, { type: "GIVE_ITEMS" }],
  [39, { type: "START_GAME" }],
]);

// === Display Configuration ===
export const DISPLAY_CONFIG = {
  TITLE_DURATION: 200, // ระยะเวลาแสดง title (ticks)
  TITLE_FADE_IN: 10, // fade in duration
  TITLE_FADE_OUT: 20, // fade out duration
  SOUND_VOLUME: 0.8, // ระดับเสียงมาตรฐาน
  SOUND_PITCH: 1, // pitch เสียงมาตรฐาน
};

// === Border Shrink Adjustment ===
// ใช้สำหรับปรับความเร็วการหด border ตามช่วงเวลา
export const BORDER_ADJUSTMENTS = [
  { tickRange: [900, 1200], adjustment: 0.3 }, // ช่วงแรก: หดช้าลง
  { tickRange: [1201, 1800], adjustment: 0.1 }, // ช่วงกลาง: หดช้าเล็กน้อย
  { tickRange: [1801, 3000], adjustment: -0.1 }, // ช่วงท้าย: หดเร็วขึ้น
];

// === Scoreboard Configuration ===
export const SCOREBOARD_CONFIG = {
  OBJECTIVE_NAME: "uhc", // ชื่อ objective
  BORDER_DISPLAY: " Border", // ชื่อแสดงสำหรับ border
  TICK_DISPLAY: " Tick", // ชื่อแสดงสำหรับ tick
};

// === Victory Configuration ===
export const VICTORY_CONFIG = {
  COUNTDOWN_DURATION: 300, // ระยะเวลา countdown หลังชนะ (ticks/15 วินาที)
  COUNTDOWN_INTERVAL: 20, // interval ของ countdown (ticks)
  TITLE_PREFIX: "§l§g", // prefix สำหรับ title
  SUBTITLE_VICTORY: "§fชนะเลิศ!", // subtitle ชนะ
  MIN_ALIVE_CHECK_TICK: 60, // tick ต่ำสุดก่อนเช็คผู้ชนะ
};
