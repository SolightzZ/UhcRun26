// ========================================
// Border Management System
// ========================================
// ระบบจัดการ border, particles, และการเตือนผู้เล่น
// แยกออกเป็น module เพื่อความชัดเจนและง่ายต่อการทดสอบ

import { BORDER_CONFIG, PARTICLE_CONFIG, WARNING_CONFIG, BORDER_ADJUSTMENTS } from "./constants.js";

import {
  getMinDistanceToBorder,
  getMaxDistanceFromCenter,
  isOutsideBorder,
  getDirectionVector,
  clampY,
  clampToBorder,
  shuffleArray,
  shouldDealDamage,
  safeExecute,
} from "./utils.js";

// ========================================
// Border Calculation Functions
// ========================================

/**
 * คำนวณ shrink rate ของ border
 * @param {number} currentRadius - รัศมีปัจจุบัน
 * @returns {number} - อัตราการหด per tick
 */
export function calculateShrinkRate(currentRadius) {
  const radiusDiff = currentRadius - BORDER_CONFIG.FINAL_RADIUS;
  return radiusDiff / BORDER_CONFIG.SHRINK_DURATION;
}

/**
 * หา adjustment สำหรับการหด border ตาม tick ปัจจุบัน
 * @param {number} tick - tick ปัจจุบัน
 * @returns {number} - ค่า adjustment
 */
export function getBorderAdjustment(tick) {
  // ใช้ find เพื่อ O(n) lookup แต่ n เล็กมาก (3 elements)
  const config = BORDER_ADJUSTMENTS.find(({ tickRange }) => tick >= tickRange[0] && tick <= tickRange[1]);

  return config ? config.adjustment : 0;
}

/**
 * คำนวณรัศมี border ใหม่หลังหด
 * @param {number} currentRadius - รัศมีปัจจุบัน
 * @param {number} tick - tick ปัจจุบัน
 * @returns {number} - รัศมีใหม่
 */
export function calculateNewBorderRadius(currentRadius, tick) {
  // ตรวจสอบว่าอยู่ในช่วงเวลาหดหรือไม่
  if (tick < BORDER_CONFIG.SHRINK_START_TICK || tick > BORDER_CONFIG.SHRINK_END_TICK) {
    return currentRadius; // ไม่หด
  }

  const shrinkRate = calculateShrinkRate(currentRadius);
  const adjustment = getBorderAdjustment(tick);
  const newRadius = currentRadius - shrinkRate + adjustment;

  // ไม่ให้ต่ำกว่า FINAL_RADIUS
  return Math.max(BORDER_CONFIG.FINAL_RADIUS, newRadius);
}

// ========================================
// Warning System
// ========================================

/**
 * คำนวณทิศทางลูกศรชี้เข้าหา center
 * @param {Object} playerLocation - ตำแหน่งผู้เล่น {x, y, z}
 * @param {Object} center - จุดศูนย์กลาง {x, z}
 * @returns {Object} - ตำแหน่งสำหรับ spawn particle {x, y, z}
 */
function calculateArrowDirection(playerLocation, center) {
  const direction = getDirectionVector({ x: playerLocation.x, z: playerLocation.z }, center);

  return {
    x: playerLocation.x + direction.x * 2,
    y: playerLocation.y + 1,
    z: playerLocation.z + direction.z * 2,
  };
}

/**
 * ทำความเสียหายและเอฟเฟกต์กับผู้เล่น
 * @param {Player} player - ผู้เล่น
 */
function applyWarningEffects(player) {
  if (!shouldDealDamage()) return;

  // แสดงข้อความเตือน
  player.onScreenDisplay.setActionBar("§cWorld Border !");

  // เล่นเสียง
  player.playSound("hit.netherite");

  // ทำความเสียหาย
  player.applyDamage(WARNING_CONFIG.DAMAGE_AMOUNT, {
    cause: WARNING_CONFIG.DAMAGE_CAUSE,
    damagingEntity: null,
  });

  // Fade หน้าจอ
  player.camera.fade({
    fadeTime: WARNING_CONFIG.FADE_TIMING,
    fadeColor: WARNING_CONFIG.FADE_COLOR,
  });
}

/**
 * เตือนผู้เล่นที่อยู่นอก border
 * @param {Player} player - ผู้เล่น
 * @param {number} borderRadius - รัศมี border ปัจจุบัน
 */
export function warnPlayerOutsideBorder(player, borderRadius) {
  const { x, z, y } = player.location;

  // ตรวจสอบว่าอยู่นอก border หรือไม่
  if (!isOutsideBorder({ x, z }, borderRadius)) return;

  // Spawn particle ลูกศรชี้เข้าหา center
  const arrowPos = calculateArrowDirection({ x, y, z }, BORDER_CONFIG.CENTER_POINT);

  safeExecute(() => {
    player.dimension.spawnParticle("arrow", arrowPos);
  }, "Spawn Arrow Particle");

  // ทำเอฟเฟกต์เตือน
  applyWarningEffects(player);
}

// ========================================
// Particle System
// ========================================

/**
 * คำนวณ intensity ของ particle ตามระยะห่าง
 * @param {number} distanceToBorder - ระยะห่างถึง border
 * @returns {number} - intensity (0-1)
 */
function calculateParticleIntensity(distanceToBorder) {
  return Math.max(0, 1 - distanceToBorder / PARTICLE_CONFIG.PROXIMITY_THRESHOLD);
}

/**
 * คำนวณช่วงการ spawn particle
 * @param {number} intensity - intensity
 * @returns {number} - ช่วง spawn
 */
function calculateParticleRange(intensity) {
  const baseRange = (Math.sqrt(PARTICLE_CONFIG.MAX_PARTICLES) * PARTICLE_CONFIG.SPACING) / 1.5;
  const maxRange = PARTICLE_CONFIG.PROXIMITY_THRESHOLD;
  return Math.min(baseRange, maxRange) * intensity;
}

/**
 * สร้าง corners ของ border (4 ทิศ)
 * @param {Object} center - จุดศูนย์กลาง {x, z}
 * @param {number} radius - รัศมี
 * @returns {Object[]} - array ของ corners
 */
function createBorderCorners(center, radius) {
  return [
    { x: center.x + radius, z: null }, // ทิศขวา
    { x: center.x - radius, z: null }, // ทิศซ้าย
    { x: null, z: center.z + radius }, // ทิศล่าง
    { x: null, z: center.z - radius }, // ทิศบน
  ];
}

/**
 * ตรวจสอบว่า corner อยู่ในระยะที่แสดง particle ได้หรือไม่
 * @param {Object} corner - corner {x, z}
 * @param {Object} playerLocation - ตำแหน่งผู้เล่น {x, z}
 * @returns {boolean} - true ถ้าอยู่ในระยะ
 */
function isCornerInRange(corner, playerLocation) {
  const dx = corner.x !== null ? Math.abs(corner.x - playerLocation.x) : 0;
  const dz = corner.z !== null ? Math.abs(corner.z - playerLocation.z) : 0;
  const distance = Math.sqrt(dx * dx + dz * dz);

  return distance <= PARTICLE_CONFIG.PROXIMITY_THRESHOLD;
}

/**
 * สร้าง particle points สำหรับ corner หนึ่งอัน
 * @param {Object} corner - corner {x, z}
 * @param {Object} playerLocation - ตำแหน่งผู้เล่น {x, y, z}
 * @param {number} particleRange - ช่วง spawn particle
 * @param {Object} center - จุดศูนย์กลาง
 * @param {number} borderRadius - รัศมี border
 * @returns {Object[]} - array ของจุด particle {x, y, z}
 */
function generateCornerParticles(corner, playerLocation, particleRange, center, borderRadius) {
  const particles = [];

  // วน grid offset
  for (let xOffset = -particleRange; xOffset < particleRange; xOffset += PARTICLE_CONFIG.SPACING) {
    for (let yOffset = -particleRange; yOffset < particleRange; yOffset += PARTICLE_CONFIG.SPACING) {
      // คำนวณพิกัด particle
      const particleX = corner.x !== null ? corner.x : clampToBorder(playerLocation.x + xOffset, center.x, borderRadius);

      const particleZ = corner.z !== null ? corner.z : clampToBorder(playerLocation.z + xOffset, center.z, borderRadius);

      const particleY = clampY(playerLocation.y + yOffset);

      // ตรวจสอบว่าอยู่ในระยะ render หรือไม่
      const dx = Math.abs(particleX - playerLocation.x);
      const dz = Math.abs(particleZ - playerLocation.z);

      if (dx <= PARTICLE_CONFIG.RENDER_DISTANCE && dz <= PARTICLE_CONFIG.RENDER_DISTANCE) {
        particles.push({ x: particleX, y: particleY, z: particleZ });
      }
    }
  }

  return particles;
}

/**
 * สร้างและ spawn border particles สำหรับผู้เล่น
 * @param {Player} player - ผู้เล่น
 * @param {number} borderRadius - รัศมี border ปัจจุบัน
 */
export function spawnBorderParticles(player, borderRadius) {
  const { location, dimension } = player;

  // คำนวณระยะห่างถึง border
  const distanceToBorder = getMinDistanceToBorder(location, BORDER_CONFIG.CENTER_POINT, borderRadius);

  // ถ้าไกลเกินไป ไม่ต้องแสดง particle
  if (distanceToBorder > PARTICLE_CONFIG.PROXIMITY_THRESHOLD) return;

  // คำนวณ intensity และ range
  const intensity = calculateParticleIntensity(distanceToBorder);
  const particleRange = calculateParticleRange(intensity);

  // สร้าง corners
  const corners = createBorderCorners(BORDER_CONFIG.CENTER_POINT, borderRadius);

  // เก็บจุด particle ทั้งหมด
  const allParticles = [];

  // วนแต่ละ corner
  for (const corner of corners) {
    // ตรวจสอบว่า corner อยู่ในระยะหรือไม่
    if (!isCornerInRange(corner, location)) continue;

    // สร้าง particles สำหรับ corner นี้
    const cornerParticles = generateCornerParticles(corner, location, particleRange, BORDER_CONFIG.CENTER_POINT, borderRadius);

    allParticles.push(...cornerParticles);
  }

  // สุ่มและตัดเหลือ MAX_PARTICLES
  const selectedParticles = shuffleArray(allParticles).slice(0, PARTICLE_CONFIG.MAX_PARTICLES);

  // Spawn particles
  for (const { x, y, z } of selectedParticles) {
    safeExecute(() => {
      dimension.spawnParticle("borderX", {
        x,
        y: y + PARTICLE_CONFIG.Y_OFFSET,
        z,
      });
    }, "Spawn Border Particle");
  }
}

/**
 * จัดการ particles และ warnings สำหรับผู้เล่น
 * @param {Player} player - ผู้เล่น
 * @param {number} borderRadius - รัศมี border ปัจจุบัน
 */
export function handlePlayerBorderStatus(player, borderRadius) {
  const distanceToBorder = getMinDistanceToBorder(player.location, BORDER_CONFIG.CENTER_POINT, borderRadius);

  const maxDistance = getMaxDistanceFromCenter(player.location);

  // กรณี 1: ใกล้ border แต่ยังไม่ออก → แสดง particles
  if (distanceToBorder <= PARTICLE_CONFIG.PROXIMITY_THRESHOLD && maxDistance <= borderRadius) {
    spawnBorderParticles(player, borderRadius);
  }
  // กรณี 2: ออกนอก border → warning + particles
  else if (maxDistance > borderRadius) {
    warnPlayerOutsideBorder(player, borderRadius);
    spawnBorderParticles(player, borderRadius);
  }
}

// ========================================
// Border Warning Broadcast
// ========================================

/**
 * ตรวจสอบและ broadcast เตือน border
 * @param {Player[]} players - รายการผู้เล่น
 * @param {number} borderRadius - รัศมีปัจจุบัน
 * @param {Set} warningRadii - Set ของรัศมีที่ต้องเตือน
 * @param {Function} broadcastFn - function สำหรับ broadcast
 * @returns {Promise<boolean>} - true ถ้ามีการเตือน
 */
export async function checkAndBroadcastBorderWarning(players, borderRadius, warningRadii, broadcastFn) {
  // ตรวจสอบว่ารัศมีปัจจุบันอยู่ใน warning set หรือไม่
  const roundedRadius = Math.floor(borderRadius);

  if (!warningRadii.has(roundedRadius) || players.length === 0) {
    return false;
  }

  // Broadcast เตือน
  await broadcastFn(players, {
    message: `§c⚠ Border §f${roundedRadius}`,
    title: `§c${roundedRadius}`,
    subtitle: "",
    sound: "noti",
  });

  return true;
}
