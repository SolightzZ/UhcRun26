// ========================================
// Utility Functions
// ========================================
// ไฟล์นี้เก็บ helper functions ที่ใช้ร่วมกันหลายที่
// แยกออกมาเพื่อลด code duplication และเพิ่มความสามารถในการทดสอบ

import { PARTICLE_CONFIG, WARNING_CONFIG } from "./constants.js";

// === Player Validation ===

/**
 * ตรวจสอบว่าผู้เล่นยังมีตัวตนในเกมหรือไม่
 * @param {Player} player - ผู้เล่นที่ต้องการตรวจสอบ
 * @returns {boolean} - true ถ้าผู้เล่นยัง valid
 */
export function isPlayerValid(player) {
  try {
    const { dimension, location } = player;
    return !!dimension && !!location && player.isValid();
  } catch {
    return false;
  }
}

/**
 * กรองผู้เล่นที่ valid เท่านั้น
 * @param {Player[]} players - รายการผู้เล่น
 * @returns {Player[]} - รายการผู้เล่นที่ valid
 */
export function filterValidPlayers(players) {
  return players.filter(isPlayerValid);
}

// === Mathematical Calculations ===

/**
 * คำนวณระยะทาง Euclidean ระหว่างสองจุด
 * @param {Object} point1 - จุดแรก {x, z}
 * @param {Object} point2 - จุดที่สอง {x, z}
 * @returns {number} - ระยะทาง
 */
export function calculateDistance(point1, point2) {
  const dx = point1.x - point2.x;
  const dz = point1.z - point2.z;
  return Math.sqrt(dx * dx + dz * dz);
}

/**
 * คำนวณระยะใกล้สุดจากตำแหน่งถึง border (4 ทิศ)
 * @param {Object} location - ตำแหน่ง {x, z}
 * @param {Object} center - จุดศูนย์กลาง {x, z}
 * @param {number} radius - รัศมี border
 * @returns {number} - ระยะห่างขั้นต่ำ
 */
export function getMinDistanceToBorder(location, center, radius) {
  return Math.min(
    Math.abs(center.x + radius - location.x), // ทิศขวา
    Math.abs(center.x - radius - location.x), // ทิศซ้าย
    Math.abs(center.z + radius - location.z), // ทิศล่าง
    Math.abs(center.z - radius - location.z), // ทิศบน
  );
}

/**
 * คำนวณระยะไกลสุดจากจุดศูนย์กลาง (Max Manhattan Distance)
 * @param {Object} location - ตำแหน่ง {x, z}
 * @returns {number} - ระยะห่างสูงสุด
 */
export function getMaxDistanceFromCenter(location) {
  return Math.max(Math.abs(location.x), Math.abs(location.z));
}

/**
 * ตรวจสอบว่าผู้เล่นอยู่นอก border หรือไม่
 * @param {Object} location - ตำแหน่ง {x, z}
 * @param {number} radius - รัศมี border
 * @returns {boolean} - true ถ้าอยู่นอก border
 */
export function isOutsideBorder(location, radius) {
  return Math.abs(location.x) > radius || Math.abs(location.z) > radius;
}

// === Vector Operations ===

/**
 * คำนวณ unit vector ชี้จาก from ไป to
 * @param {Object} from - จุดเริ่มต้น {x, z}
 * @param {Object} to - จุดปลายทาง {x, z}
 * @returns {Object} - unit vector {x, z}
 */
export function getDirectionVector(from, to) {
  const dx = to.x - from.x;
  const dz = to.z - from.z;
  const distance = Math.sqrt(dx * dx + dz * dz) || 1; // ป้องกันหารด้วย 0

  return {
    x: dx / distance,
    z: dz / distance,
  };
}

// === Coordinate Utilities ===

/**
 * จำกัดค่า y ให้อยู่ในช่วงที่กำหนด
 * @param {number} y - ค่า y
 * @returns {number} - ค่า y ที่ clamp แล้ว
 */
export function clampY(y) {
  return Math.max(PARTICLE_CONFIG.Y_MIN, Math.min(PARTICLE_CONFIG.Y_MAX, y));
}

/**
 * จำกัดพิกัด x หรือ z ให้อยู่ภายใน border
 * @param {number} value - ค่าพิกัด
 * @param {number} center - จุดศูนย์กลาง
 * @param {number} radius - รัศมี
 * @returns {number} - ค่าที่ clamp แล้ว
 */
export function clampToBorder(value, center, radius) {
  return Math.max(center - radius, Math.min(center + radius, value));
}

// === Array Utilities ===

/**
 * สุ่มเรียงลำดับ array (Fisher-Yates Shuffle)
 * @param {Array} array - array ที่ต้องการสุ่ม
 * @returns {Array} - array ที่สุ่มแล้ว (copy ใหม่)
 */
export function shuffleArray(array) {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

/**
 * สุ่มเลือก element จาก array
 * @param {Array} array - array
 * @returns {*} - element ที่สุ่มได้
 */
export function randomElement(array) {
  return array[Math.floor(Math.random() * array.length)];
}

// === Team Utilities ===

/**
 * หา tag ทีมของผู้เล่น
 * @param {Player} player - ผู้เล่น
 * @param {string[]} teamTags - รายการ tag ทีม
 * @returns {string|null} - tag ทีมหรือ null
 */
export function getPlayerTeam(player, teamTags) {
  return teamTags.find((tag) => player.hasTag(tag)) ?? null;
}

/**
 * หาข้อมูลทีมจาก tag
 * @param {string} teamTag - tag ทีม
 * @param {Object[]} teams - รายการข้อมูลทีม
 * @returns {Object|null} - ข้อมูลทีมหรือ null
 */
export function getTeamInfo(teamTag, teams) {
  return teams.find((team) => team.tag === teamTag) ?? null;
}

/**
 * นับจำนวนทีมที่ยังมีสมาชิกอยู่
 * @param {Player[]} players - รายการผู้เล่น
 * @param {string[]} teamTags - รายการ tag ทีม
 * @returns {Set<string>} - Set ของ tag ทีมที่ยังมีสมาชิก
 */
export function getActiveTeams(players, teamTags) {
  const activeTeams = new Set();

  for (const player of players) {
    const team = getPlayerTeam(player, teamTags);
    if (team) {
      activeTeams.add(team);
    }
  }

  return activeTeams;
}

// === Particle Utilities ===

/**
 * สร้าง grid ของจุด particle
 * @param {Object} options - ตัวเลือก
 * @returns {Object[]} - array ของจุด particle {x, y, z}
 */
export function generateParticleGrid({ centerX, centerY, centerZ, range, spacing, filter = () => true }) {
  const particles = [];

  for (let xOffset = -range; xOffset < range; xOffset += spacing) {
    for (let yOffset = -range; yOffset < range; yOffset += spacing) {
      const x = centerX + xOffset;
      const y = centerY + yOffset;
      const z = centerZ;

      if (filter({ x, y, z })) {
        particles.push({ x, y: clampY(y), z });
      }
    }
  }

  return particles;
}

// === Damage Utilities ===

/**
 * ตรวจสอบว่าควรทำความเสียหายหรือไม่ (ตาม chance)
 * @param {number} chance - โอกาส (0-1)
 * @returns {boolean} - true ถ้าควรทำความเสียหาย
 */
export function shouldDealDamage(chance = WARNING_CONFIG.DAMAGE_CHANCE) {
  return Math.random() < chance;
}

// === String Utilities ===

/**
 * สร้าง progress bar string
 * @param {number} current - ค่าปัจจุบัน
 * @param {number} total - ค่าสูงสุด
 * @param {string} filledChar - ตัวอักษรสำหรับส่วนที่เติม
 * @param {string} emptyChar - ตัวอักษรสำหรับส่วนที่ว่าง
 * @param {string} filledColor - สีส่วนที่เติม
 * @param {string} emptyColor - สีส่วนที่ว่าง
 * @returns {string} - progress bar string
 */
export function createProgressBar(current, total, filledChar = "▌", emptyChar = "▌", filledColor = "§a", emptyColor = "§f") {
  let bar = "";

  for (let i = 0; i < total; i++) {
    bar += i < current ? `${filledColor}${filledChar}` : `${emptyColor}${emptyChar}`;
  }

  return bar;
}

// === Promise Utilities ===

/**
 * รัน async function ทั้งหมด parallel (เพื่อประสิทธิภาพ)
 * @param {Array} items - รายการ items
 * @param {Function} asyncFn - async function ที่จะรันกับแต่ละ item
 * @returns {Promise<Array>} - ผลลัพธ์ทั้งหมด
 */
export async function parallelMap(items, asyncFn) {
  return Promise.all(items.map(asyncFn));
}

/**
 * รัน async function แบบ batch (เพื่อควบคุม concurrent limit)
 * @param {Array} items - รายการ items
 * @param {Function} asyncFn - async function
 * @param {number} batchSize - ขนาด batch
 * @returns {Promise<Array>} - ผลลัพธ์ทั้งหมด
 */
export async function batchProcess(items, asyncFn, batchSize = 10) {
  const results = [];

  for (let i = 0; i < items.length; i += batchSize) {
    const batch = items.slice(i, i + batchSize);
    const batchResults = await Promise.all(batch.map(asyncFn));
    results.push(...batchResults);
  }

  return results;
}

// === Time Utilities ===

/**
 * แปลง ticks เป็นวินาที
 * @param {number} ticks - จำนวน ticks
 * @returns {number} - จำนวนวินาที
 */
export function ticksToSeconds(ticks) {
  return Math.floor(ticks / 20);
}

/**
 * แปลงวินาทีเป็น ticks
 * @param {number} seconds - จำนวนวินาที
 * @returns {number} - จำนวน ticks
 */
export function secondsToTicks(seconds) {
  return seconds * 20;
}

// === Debug Utilities ===

/**
 * Log error ด้วย context
 * @param {string} context - context ของ error
 * @param {Error} error - error object
 */
export function logError(context, error) {
  console.warn(`[UHC Error - ${context}]: ${error.message}`);
}

/**
 * Safe execute: รัน function และจัดการ error
 * @param {Function} fn - function ที่จะรัน
 * @param {string} context - context สำหรับ error
 * @returns {*} - ผลลัพธ์หรือ null ถ้ามี error
 */
export function safeExecute(fn, context) {
  try {
    return fn();
  } catch (error) {
    logError(context, error);
    return null;
  }
}
