// ========================================
// Broadcast & Display System
// ========================================
// ระบบจัดการการส่งข้อความ, title, sound และ effects ให้ผู้เล่น
// แยกออกเป็น module เพื่อความชัดเจนและลด coupling

import { DISPLAY_CONFIG } from "./constants.js";
import { parallelMap, safeExecute } from "./utils.js";

// ========================================
// Core Broadcast Function
// ========================================

/**
 * ส่งข้อความและเอฟเฟกต์ให้ผู้เล่นหลายคน (Async)
 * @param {Player[]} players - รายการผู้เล่น
 * @param {Object} options - ตัวเลือกการ broadcast
 * @param {string} [options.message] - ข้อความ chat
 * @param {string} [options.title] - Title
 * @param {string} [options.subtitle] - Subtitle
 * @param {string} [options.sound] - ชื่อเสียง
 * @param {string} [options.actionBar] - Action bar message
 * @param {Object} [options.titleOptions] - ตัวเลือก title
 * @param {Object} [options.soundOptions] - ตัวเลือก sound
 * @returns {Promise<void>}
 */
export async function broadcastToPlayers(players, options = {}) {
  const { message, title, subtitle, sound, actionBar, titleOptions = {}, soundOptions = {} } = options;

  // ใช้ parallel execution สำหรับประสิทธิภาพ
  await parallelMap(players, async (player) => {
    const commands = [];

    // ส่งข้อความ
    if (message) {
      commands.push(safeExecute(() => player.sendMessage(message), "Send Message"));
    }

    // แสดง title/subtitle
    if (title || subtitle) {
      const displayOptions = {
        stayDuration: titleOptions.stayDuration ?? DISPLAY_CONFIG.TITLE_DURATION,
        fadeInDuration: titleOptions.fadeInDuration ?? DISPLAY_CONFIG.TITLE_FADE_IN,
        fadeOutDuration: titleOptions.fadeOutDuration ?? DISPLAY_CONFIG.TITLE_FADE_OUT,
        subtitle: subtitle || "",
      };

      commands.push(safeExecute(() => player.onScreenDisplay.setTitle(title || "", displayOptions), "Set Title"));
    }

    // เล่นเสียง
    if (sound) {
      const audioOptions = {
        volume: soundOptions.volume ?? DISPLAY_CONFIG.SOUND_VOLUME,
        pitch: soundOptions.pitch ?? DISPLAY_CONFIG.SOUND_PITCH,
      };

      commands.push(safeExecute(() => player.playSound(sound, audioOptions), "Play Sound"));
    }

    // แสดง action bar
    if (actionBar !== undefined) {
      commands.push(safeExecute(() => player.onScreenDisplay.setActionBar(actionBar), "Set Action Bar"));
    }

    // รอให้ทุกคำสั่งเสร็จ
    await Promise.all(commands.filter(Boolean));
  });
}

// ========================================
// Specialized Broadcast Functions
// ========================================

/**
 * ส่ง title เท่านั้น
 * @param {Player[]} players - รายการผู้เล่น
 * @param {string} title - Title
 * @param {string} [subtitle] - Subtitle
 * @param {Object} [options] - ตัวเลือก
 */
export async function broadcastTitle(players, title, subtitle = "", options = {}) {
  await broadcastToPlayers(players, {
    title,
    subtitle,
    titleOptions: options,
  });
}

/**
 * ส่งเสียงเท่านั้น
 * @param {Player[]} players - รายการผู้เล่น
 * @param {string} sound - ชื่อเสียง
 * @param {Object} [options] - ตัวเลือกเสียง
 */
export async function broadcastSound(players, sound, options = {}) {
  await broadcastToPlayers(players, {
    sound,
    soundOptions: options,
  });
}

/**
 * ส่งข้อความ chat เท่านั้น
 * @param {Player[]} players - รายการผู้เล่น
 * @param {string} message - ข้อความ
 */
export async function broadcastMessage(players, message) {
  await broadcastToPlayers(players, { message });
}

/**
 * แสดง action bar เท่านั้น
 * @param {Player[]} players - รายการผู้เล่น
 * @param {string} actionBar - ข้อความ action bar
 */
export async function broadcastActionBar(players, actionBar) {
  await broadcastToPlayers(players, { actionBar });
}

// ========================================
// Camera Effects
// ========================================

/**
 * ทำ camera fade effect
 * @param {Player[]} players - รายการผู้เล่น
 * @param {Object} options - ตัวเลือก fade
 * @param {Object} options.fadeTime - เวลา fade
 * @param {Object} options.fadeColor - สี fade
 */
export async function applyCameraFade(players, options) {
  const { fadeTime, fadeColor } = options;

  await parallelMap(players, async (player) => {
    safeExecute(() => {
      player.camera.fade({ fadeTime, fadeColor });
    }, "Camera Fade");
  });
}

// ========================================
// Input Control
// ========================================

/**
 * ล็อก/ปลดล็อก การเคลื่อนไหวของผู้เล่น
 * @param {Player[]} players - รายการผู้เล่น
 * @param {boolean} enabled - true = เคลื่อนไหวได้, false = ล็อก
 */
export function setMovementEnabled(players, enabled) {
  for (const player of players) {
    safeExecute(() => {
      if (player.inputPermissions) {
        player.inputPermissions.movementEnabled = enabled;
      }
    }, "Set Movement");
  }
}

// ========================================
// Multiple Sound播放
// ========================================

/**
 * เล่นหลายเสียงพร้อมกัน
 * @param {Player} player - ผู้เล่น
 * @param {Object[]} sounds - array ของ {name, volume, pitch}
 */
export function playMultipleSounds(player, sounds) {
  for (const { name, volume, pitch } of sounds) {
    safeExecute(() => {
      player.playSound(name, { volume, pitch });
    }, `Play Sound: ${name}`);
  }
}

/**
 * เล่นหลายเสียงให้ผู้เล่นหลายคน
 * @param {Player[]} players - รายการผู้เล่น
 * @param {Object[]} sounds - array ของ {name, volume, pitch}
 */
export async function broadcastMultipleSounds(players, sounds) {
  await parallelMap(players, async (player) => {
    playMultipleSounds(player, sounds);
  });
}
