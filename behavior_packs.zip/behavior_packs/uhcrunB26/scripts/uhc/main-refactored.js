// ========================================
// UHC Game - Main Controller (Refactored)
// ========================================
// คลาสหลักจัดการเกม UHC หลังเริ่ม
// Refactored ด้วย Clean Code principles:
// - แยก Constants, Business Logic, และ Utilities
// - ใช้ Functional Programming
// - Optimize ด้วย Big O (Map สำหรับ O(1) lookup)
// - ง่ายต่อการขยายและบำรุงรักษา

import { system, world } from "@minecraft/server";
import { dynamicToast } from "../message.js";
import { UHCManager } from "./start-refactored.js";

// Import Constants
import { BORDER_CONFIG, GAME_EVENTS, VICTORY_CONFIG } from "./constants.js";

// Import Systems
import { calculateNewBorderRadius, handlePlayerBorderStatus, checkAndBroadcastBorderWarning } from "./borderSystem.js";

import { broadcastToPlayers, broadcastSound } from "./broadcastSystem.js";

import { updateScoreboardForPlayers } from "./scoreboardSystem.js";

import { checkVictoryCondition, getWinningTeam } from "./teamSystem.js";

import { filterValidPlayers, parallelMap } from "./utils.js";

// ========================================
// UHC Game Class - Refactored
// ========================================

class UHCGame {
  // === State Management ===
  static gameState = {
    isRunning: false,
    tickCount: 0,
    borderRadius: BORDER_CONFIG.INITIAL_RADIUS,
  };

  // === Interval IDs ===
  static intervals = {
    countdown: null,
    gameLoop: null,
  };

  // === Warning Sets (ใช้ Set สำหรับ O(1) lookup) ===
  static warningCache = {
    borderRadii: new Set(BORDER_CONFIG.WARNING_RADII),
    countdownTimes: new Set(BORDER_CONFIG.COUNTDOWN_TIMES),
  };

  // ========================================
  // Game Control Methods
  // ========================================

  /**
   * เริ่มเกม
   */
  static startGame() {
    if (this.gameState.isRunning) return;

    this.resetGameState();
    this.gameState.isRunning = true;
    this.runGameLoop();
  }

  /**
   * หยุดเกม
   */
  static stopGame() {
    if (!this.gameState.isRunning) return;

    this.gameState.isRunning = false;
    this.resetGameState();
    this.clearAllIntervals();
  }

  /**
   * รีเซ็ตสถานะเกม
   */
  static resetGameState() {
    this.gameState.tickCount = 0;
    this.gameState.borderRadius = BORDER_CONFIG.INITIAL_RADIUS;
  }

  /**
   * ล้าง intervals ทั้งหมด
   */
  static clearAllIntervals() {
    if (this.intervals.gameLoop) {
      system.clearRun(this.intervals.gameLoop);
      this.intervals.gameLoop = null;
    }

    if (this.intervals.countdown) {
      system.clearRun(this.intervals.countdown);
      this.intervals.countdown = null;
    }
  }

  // ========================================
  // Player Management
  // ========================================

  /**
   * หาผู้เล่นที่เข้าร่วม UHC
   * @returns {Player[]} - รายการผู้เล่น UHC
   */
  static getUHCPlayers() {
    const allPlayers = world.getPlayers();
    return allPlayers.filter((p) => p.hasTag("uhc"));
  }

  /**
   * หาผู้เล่น UHC ที่ valid
   * @returns {Player[]} - รายการผู้เล่น valid
   */
  static getValidUHCPlayers() {
    const uhcPlayers = this.getUHCPlayers();
    return filterValidPlayers(uhcPlayers);
  }

  // ========================================
  // Game Loop - Main Logic
  // ========================================

  /**
   * Game loop หลัก (รันทุก 20 ticks = 1 วินาที)
   */
  static runGameLoop() {
    this.intervals.gameLoop = system.runInterval(async () => {
      if (!this.gameState.isRunning) return;

      // เพิ่ม tick
      this.gameState.tickCount++;
      console.info(`UHC Tick: ${this.gameState.tickCount}`);

      // ดึงผู้เล่น
      const allPlayers = world.getPlayers();
      const uhcPlayers = this.getValidUHCPlayers();

      // === Core Game Systems ===
      await this.updateGameSystems(allPlayers, uhcPlayers);

      // === Game Events ===
      await this.processGameEvents(allPlayers, uhcPlayers);

      // === Player Border Handling ===
      this.processPlayerBorderStatus(uhcPlayers);
    }, 20); // ทุก 1 วินาที
  }

  // ========================================
  // Game Systems Update
  // ========================================

  /**
   * อัพเดตระบบหลักของเกม
   * @param {Player[]} allPlayers - ผู้เล่นทั้งหมด
   * @param {Player[]} uhcPlayers - ผู้เล่น UHC
   */
  static async updateGameSystems(allPlayers, uhcPlayers) {
    const { tickCount, borderRadius } = this.gameState;

    // 1. อัพเดต Scoreboard (Parallel)
    await parallelMap(uhcPlayers, async (player) => {
      updateScoreboardForPlayers([player], borderRadius, tickCount);
    });

    // 2. ตรวจสอบเงื่อนไขชัยชนะ
    await this.checkVictory(uhcPlayers);

    // 3. เตือน Border Warning
    await checkAndBroadcastBorderWarning(uhcPlayers, borderRadius, this.warningCache.borderRadii, broadcastToPlayers);

    // 4. ปรับ Border Radius
    this.gameState.borderRadius = calculateNewBorderRadius(borderRadius, tickCount);
  }

  // ========================================
  // Event Processing
  // ========================================

  /**
   * ประมวลผล game events ตาม tick
   * @param {Player[]} allPlayers - ผู้เล่นทั้งหมด
   * @param {Player[]} uhcPlayers - ผู้เล่น UHC
   */
  static async processGameEvents(allPlayers, uhcPlayers) {
    const { tickCount } = this.gameState;

    // === Start Phase Events (0-44 ticks) ===
    if (tickCount >= 0 && tickCount <= 44) {
      UHCManager.Timestart(uhcPlayers);
    }

    // === Countdown Events (Border Activation Warning) ===
    await this.processCountdownEvents(allPlayers);

    // === Timed Events (ใช้ Map สำหรับ O(1) lookup) ===
    await this.processTimedEvents(allPlayers);
  }

  /**
   * ประมวลผล countdown events
   * @param {Player[]} players - ผู้เล่นทั้งหมด
   */
  static async processCountdownEvents(players) {
    const { tickCount } = this.gameState;
    const timeUntilBorder = BORDER_CONFIG.ACTIVATION_TICK - tickCount;

    // ตรวจสอบว่าเป็นเวลา countdown หรือไม่ (O(1) lookup ด้วย Set)
    if (this.warningCache.countdownTimes.has(timeUntilBorder) && players.length > 0) {
      // ส่ง toast message
      world.sendMessage(
        dynamicToast(
          `§cWorld Border Active \nin §g${timeUntilBorder} §ctick`,
          "textures/ui/ErrorGlyph_small_hover",
          "textures/ui/beacon_button_locked",
        ),
      );

      // เล่นเสียง
      await broadcastSound(players, "note.pling");
    }
  }

  /**
   * ประมวลผล timed events (O(1) lookup ด้วย Map)
   * @param {Player[]} players - ผู้เล่นทั้งหมด
   */
  static async processTimedEvents(players) {
    const { tickCount } = this.gameState;

    // ดึง event จาก Map (O(1))
    const event = GAME_EVENTS.get(tickCount);
    if (!event) return;

    // ประมวลผลตาม event type
    await this.handleTimedEvent(event, players);
  }

  /**
   * จัดการ timed event แต่ละ type
   * @param {Object} event - event object
   * @param {Player[]} players - ผู้เล่น
   */
  static async handleTimedEvent(event, players) {
    switch (event.type) {
      case "PVP_DISABLE":
        await broadcastToPlayers(players, event.broadcast);
        world.gameRules.pvp = false;
        break;

      case "PVP_ENABLE":
        await broadcastToPlayers(players, event.broadcast);
        world.gameRules.pvp = true;
        break;

      case "BORDER_WARNING":
      case "PVP_ENABLE_WARNING":
      case "PVP_COUNTDOWN":
        await broadcastToPlayers(players, event.broadcast);
        break;

      case "CREDIT":
        if (event.toast) {
          world.sendMessage(dynamicToast(event.toast.message, event.toast.icon, event.toast.frame));
        }
        if (event.sound) {
          await broadcastSound(players, event.sound);
        }
        break;

      case "BORDER_ACTIVE":
        await broadcastToPlayers(players, event.broadcast);
        break;

      case "MOB_DISABLE":
        await broadcastToPlayers(players, event.broadcast);
        world.gameRules.mobGriefing = false;
        world.gameRules.doMobSpawning = false;
        break;
    }
  }

  // ========================================
  // Player Border Processing
  // ========================================

  /**
   * ประมวลผลสถานะ border สำหรับผู้เล่นทั้งหมด
   * @param {Player[]} uhcPlayers - ผู้เล่น UHC
   */
  static processPlayerBorderStatus(uhcPlayers) {
    const { borderRadius } = this.gameState;

    for (const player of uhcPlayers) {
      handlePlayerBorderStatus(player, borderRadius);
    }
  }

  // ========================================
  // Victory System
  // ========================================

  /**
   * ตรวจสอบเงื่อนไขชัยชนะ
   * @param {Player[]} uhcPlayers - ผู้เล่น UHC
   */
  static async checkVictory(uhcPlayers) {
    const victoryResult = checkVictoryCondition(uhcPlayers, this.gameState.tickCount);

    if (victoryResult && victoryResult.shouldEnd) {
      await this.triggerVictory(victoryResult.winningTeam);
    }
  }

  /**
   * เริ่ม victory sequence
   * @param {Object} winningTeam - ทีมที่ชนะ
   */
  static async triggerVictory(winningTeam) {
    if (!winningTeam) return;

    const allPlayers = world.getPlayers();

    // ประกาศผู้ชนะ
    await broadcastToPlayers(allPlayers, {
      message: `§l§a${winningTeam.color}${winningTeam.name} §aWin!`,
      title: `${winningTeam.color}${winningTeam.name}`,
      subtitle: VICTORY_CONFIG.SUBTITLE_VICTORY,
      sound: "world_noti",
    });

    // เริ่ม countdown
    this.startVictoryCountdown(allPlayers, winningTeam);
  }

  /**
   * เริ่ม victory countdown
   * @param {Player[]} players - ผู้เล่นทั้งหมด
   * @param {Object} winningTeam - ทีมที่ชนะ
   */
  static startVictoryCountdown(players, winningTeam) {
    let countdown = VICTORY_CONFIG.COUNTDOWN_DURATION;

    this.intervals.countdown = system.runInterval(async () => {
      countdown -= VICTORY_CONFIG.COUNTDOWN_INTERVAL;

      if (countdown <= 0) {
        // หมดเวลา countdown
        system.clearRun(this.intervals.countdown);
        this.intervals.countdown = null;

        // ส่งข้อความสุดท้าย
        await broadcastToPlayers(players, {
          message: `${winningTeam.color}${winningTeam.name} §fเป็นผู้ชนะ!`,
          title: VICTORY_CONFIG.TITLE_PREFIX + countdown,
          sound: "note.pling",
        });

        return;
      }

      // แสดง countdown
      await broadcastToPlayers(players, {
        title: VICTORY_CONFIG.TITLE_PREFIX + countdown,
        sound: "note.pling",
      });
    }, VICTORY_CONFIG.COUNTDOWN_INTERVAL);
  }
}

// ========================================
// Script Event Handler
// ========================================

system.afterEvents.scriptEventReceive.subscribe((event) => {
  if (!event.sourceEntity) return;

  switch (event.id) {
    case "main:start":
      UHCGame.startGame();
      break;

    case "main:stop":
      UHCGame.stopGame();
      break;
  }
});

// ========================================
// Export
// ========================================

export { UHCGame };
