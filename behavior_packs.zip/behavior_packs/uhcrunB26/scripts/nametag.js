import { world } from "@minecraft/server";

const TAG_PREFIX = "nametag:";
const PLACEHOLDER_SELF = "@s";
const NEWLINE_TOKEN = "\\n";

const initialized = new Set();

function onPlayerSpawn(event) {
  const player = event.player;
  if (initialized.has(player.id)) return;

  initialized.add(player.id);
  initPlayerNameTag(player);
}

function initPlayerNameTag(player) {
  const raw = getRawNameTag(player);
  if (!raw) return;

  player.removeTag(raw);
  player.nameTag = buildNameTag(raw, player);
}

function getRawNameTag(player) {
  return player.getTags().find((t) => t.startsWith(TAG_PREFIX));
}

function buildNameTag(rawTag, player) {
  return rawTag.replace(TAG_PREFIX, "").replaceAll(PLACEHOLDER_SELF, player.name).replaceAll(NEWLINE_TOKEN, "\n");
}

world.afterEvents.playerSpawn.subscribe(onPlayerSpawn);
