import { world, system } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { openTeleportMenu } from "./chat";

const SCORE_KILLS = "kills";
const SCORE_DEATHS = "deaths";

export async function Stats(player) {
  const stats = getPlayerStats(player);
  const body = buildStatsBody(player, stats);

  const form = new ActionFormData();
  form.title("UHCRun Profile").body(body).button("Next");

  if (player.hasTag("gamemode")) {
    form.button("Back");
  }

  const res = await form.show(player);
  if (res.selection === 0) {
    showTips(player);
  } else if (res.selection === 1) {
    openTeleportMenu(player);
  }
}

function getPlayerStats(player) {
  const kills = getScore(player, SCORE_KILLS);
  const deaths = getScore(player, SCORE_DEATHS);
  const kdr = deaths !== 0 ? (kills / deaths).toFixed(2) : kills;
  const platform = getPlatformLabel(player);

  return { kills, deaths, kdr, platform };
}

function buildStatsBody(player, stats) {
  return (
    `\n§c  §l\u00BB §rName: §7${player.name}` +
    `\n§6  §l\u00BB §rPlatform: §7${stats.platform}` +
    `\n§g  §l\u00BB §rKills: §7${stats.kills}` +
    `\n§a  §l\u00BB §rDeaths: §7${stats.deaths}` +
    `\n§9  §l\u00BB §rKDR: §7${stats.kdr}\n `
  );
}

async function showTips(player) {
  const form = new ActionFormData();
  form
    .title("UHCRun Tips")
    .body(
      `\n§d §l\u00BB§r  สามารถพิมพ์ '§btp§r' ลงในช่องแชทเพื่อเลือก` +
        `\n    เทเลพอร์ต ไปยังผู้เล่นอื่นๆได้` +
        `\n§5 §l\u00BB§f  ขอบคุณที่มาเล่นนะครับ/ค่ะ \n `,
    )
    .button("Back")
    .button("Close");

  const res = await form.show(player);
  if (res.selection === 0) {
    Stats(player);
  }
}

function getScore(player, objective) {
  const obj = world.scoreboard.getObjective(objective);
  if (!obj) return 0;
  return obj.getScore(player.scoreboardIdentity) ?? 0;
}

function getPlatformLabel(player) {
  const raw = player.clientSystemInfo?.platformType;
  if (!raw) return "Unknown";

  const platformMap = {
    mobile: "Mobile",
    desktop: "Desktop",
    console: "Console",
  };

  return platformMap[String(raw).toLowerCase()] || "Unknown";
}

function onScriptEvent(event) {
  const player = event.sourceEntity;
  if (!player || event.id !== "show:stats") return;

  system.runTimeout(() => {
    Stats(player);
  }, 60);
}

system.afterEvents.scriptEventReceive.subscribe(onScriptEvent);
