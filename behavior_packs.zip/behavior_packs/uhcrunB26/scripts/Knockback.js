import { world } from "@minecraft/server";

const SOUND_EFFECTS = ["mob.shulker.shoot", "firework.blast", "firework.large_blast", "firework.twinkle"];
const SPECIAL_PLATES = new Set(["minecraft:crimson_pressure_plate"]);
const KB = {
  HIT: { h: 0.76, v: 0.42 },
  PLATE: { h: 3, v: 1.5 },
};

world.afterEvents.entityHurt.subscribe(onEntityHurt);
world.afterEvents.pressurePlatePush.subscribe(onPressurePlate);

function onEntityHurt(event) {
  handlePlayerHit(event);
}

function onPressurePlate(event) {
  handlePlatePush(event);
}

function handlePlayerHit(event) {
  const victim = event.hurtEntity;
  const attacker = event.damageSource?.damagingEntity;

  if (!isValidPvp(victim, attacker)) return;

  const dir = attacker.getViewDirection();
  applyKnockback(victim, dir, KB.HIT);
}

function handlePlatePush(event) {
  const block = event.block;
  if (!SPECIAL_PLATES.has(block.typeId)) return;

  const player = getNearbyPlayer(block);
  if (!player) return;

  const dir = player.getViewDirection();
  applyKnockback(player, dir, KB.PLATE);
  playRandomSound(block.dimension, player);
}

function isValidPvp(victim, attacker) {
  return victim?.typeId === "minecraft:player" && attacker?.typeId === "minecraft:player" && typeof attacker.getViewDirection === "function";
}

function applyKnockback(player, dir, kb) {
  const horizontal = { x: dir.x, z: dir.z };
  const vertical = kb.v;

  player.applyKnockback(horizontal, vertical);
}

function playRandomSound(dimension, player) {
  const sound = SOUND_EFFECTS[Math.floor(Math.random() * SOUND_EFFECTS.length)];
  dimension.playSound(sound, player.location);
}

function getNearbyPlayer(block) {
  return block.dimension.getEntities({
    location: block.location,
    maxDistance: 2,
    type: "minecraft:player",
  })[0];
}
